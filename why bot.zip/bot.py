import asyncio
import hashlib
import hmac
import json
import math
import os
import random
import re
import secrets
import shutil
import time
import zlib
from collections import deque
from typing import Optional
from urllib.parse import urlencode, urlparse

import aiohttp
import discord
from aiohttp import web
from discord import app_commands
from discord.ext import tasks
from dotenv import load_dotenv

load_dotenv()
load_dotenv("settings.env")      # same thing in a file name that is easy to create on any computer
TOKEN = os.environ["DISCORD_TOKEN"]
GUILD = discord.Object(id=int(os.environ["GUILD_ID"]))
DB_FILE = os.environ.get("DB_FILE", "data.json")   # point at a persistent disk, e.g. /data/data.json

# ---------------------------------------------------------------------------
# Settings you can tweak
# ---------------------------------------------------------------------------
DAY = 24 * 60 * 60
WEEK = 7 * DAY
MAYOR_ROLE = "Mayor"
STAFF_ROLE = "Owner", "Admin"            # optional role that also counts as staff
TERM_DAYS = 14                  # length of a Mayor's term
ELECTION_HOURS = 48             # length of an election
CANDIDATE_FEE = 400_000
MAX_CANDIDATES = 5
DAILY_REWARD = 500
WEEKLY_BASE = 5_000             # /weekly pays this...
WEEKLY_STREAK_BONUS = 1_000     # ...plus this per extra week in a row...
WEEKLY_MAX_BONUS_WEEKS = 5      # ...up to this many extra weeks
BANK_FEE = 500
LOAN_FEE = 0.10                 # flat fee added to every loan
LOAN_DAYS = 2                   # time to repay before a 10% penalty
DAILY_INTEREST = 0.01           # 1% per day on the vault balance
ROB_FEE = 1_000                 # what a failed robbery costs (paid to the victim)
ROB_COOLDOWN = 60 * 60
CRIME_COOLDOWN = 2 * 60 * 60
WORK_MIN, WORK_MAX = 200, 400           # /work pays a random amount in this range
WORK_COOLDOWN = 60 * 60
TRIVIA_MIN, TRIVIA_MAX = 100, 300       # /trivia pays a random amount in this range
TRIVIA_COOLDOWN = 30 * 60               # starts when the question is shown
TRIVIA_TIME = 20                        # seconds to answer
DEFAULT_TAX = 5                         # market tax (%) when there is no Mayor / a new Mayor starts
MAX_TAX = 20                            # highest tax (%) a Mayor can set
TAX_TO_MARKET_BANK = True               # True: /transfer tax and stock fees go to the Market Bank (the Mayor, Owner and
                                        # Administrators can withdraw it). False: they are burned.

# --- Stock market ---------------------------------------------------------
STOCK_SUPPLY = 2_500            # shares that exist per stock
STOCK_MAX_PER_MEMBER = 250      # most shares one member can hold of one stock
STOCK_MIN_PRICE = 1_000.0       # prices never fall below this (and admins can't set a price under it)
STOCK_MIN_BASE = 2_000.0        # every stock's base price starts at this or higher, including new companies
# (ticker, name, base price). Wide spread on purpose: a cheap 2k stock for small wallets up to a 100k blue chip.
# Only used when data.json has no stocks yet; existing stocks are lifted once by lift_old_stock_prices().
STOCK_SEEDS = [
    ("WPM", "Why Production Media", 2_150),
    ("BET", "Betcoin", 4_300),
    ("VNG", "Vanguard Armaments", 9_200),
    ("WSQ", "Square One Holdings", 18_500),
    ("AERO", "Apex Aerospace", 31_000),
    ("WHY", "Why Corp", 54_000),
    ("CRYP", "Cipher Intelligence", 100_000),
]
STOCK_MIN_FEE = 3               # trading fee (%) never goes below this, even if the Mayor sets the tax lower.
                                # A buy moves the price up to 4%, so a round trip must cost more than that
                                # or members could farm free medals by buying and selling.
STOCK_TICK_SECONDS = 25         # how often prices move
STOCK_HIST_POINTS = 60          # price history kept per stock
STOCK_IMPACT_CAP = 0.04         # one trade moves the price by at most 4%...
STOCK_IMPACT_RATE = 1.2         # ...by (shares / supply) * this
STOCK_DIVIDEND = 0.004          # dividend paid per hour, as a share of position value
STOCK_DIV_INTERVAL = 60 * 60
STOCK_DIV_CATCHUP = 24          # most missed hours paid out after the bot was offline
STOCK_FOUND_COST = 25_000       # cost to found a company
STOCK_MAX_LISTED = 30

# --- Website leaderboards and Virtual Earth ---------------------------------
LB_SIZE = 10                    # rows on each website leaderboard
EARTH_MAX_PER_MEMBER = 1        # free lands one member can claim (0 = no limit). More land comes by war or buyout.
# Every land starts unclaimed. A claim is saved to data.json the moment someone makes it.
# Keep this list in step with the nat(...) lines in hub.html.
EARTH_NATIONS = {
    "DE": "Germany", "GB": "United Kingdom", "FR": "France", "NO": "Norway", "SE": "Sweden",
    "FI": "Finland", "IT": "Italy", "ES": "Spain", "PL": "Poland", "UA": "Ukraine",
    "RU": "Russia", "TR": "Turkiye", "EG": "Egypt", "MA": "Morocco", "NG": "Nigeria",
    "ZA": "South Africa", "US": "United States", "CA": "Canada", "MX": "Mexico", "BR": "Brazil",
    "AR": "Argentina", "IN": "India", "CN": "China", "JP": "Japan", "AU": "Australia",
}
# Random walk. The drift/crash numbers are the hub's formula, run once per tick.
STOCK_DRIFT = 0.028             # each tick moves by (random - 0.5) * this
STOCK_CRASH_CHANCE = 0.015      # chance per tick of an extra -5% crash
STOCK_CRASH_SIZE = 0.05
# Left alone, the crash makes every price slide to the floor within days (it averages
# -0.075% per tick), and the walk wanders without limit. These two keep prices roaming
# around the stock's base price instead. Set both to 0 for the hub's exact formula.
STOCK_CRASH_COMPENSATE = True   # add back the crash's average loss so it doesn't drag prices down
STOCK_REVERT = 0.001            # per-tick pull back toward the base price (half-life about 5 hours)

# --- Casino dice, Market Bank and the Virtual Earth economy ---------------------
DICE_MIN_BET = 100              # /dice and the website's Dice Duel (the page says 100 M too)
MARKET_BANK_LOG = 30            # how many deposits and withdrawals the Market Bank remembers
EARTH_BASE_YIELD = 1_000        # medals per hour one land earns before policies. This is the number to tune.
EARTH_CAP_HOURS = 24            # yield stops piling up after this many hours without a harvest
POLICY_COOLDOWN = 60 * 60       # each policy category can change once an hour
DEFAULT_POLICY = {"eco": "balanced", "mil": "volunteer", "dip": "neutral", "gov": "dictatorship"}
# National policies. The website reads this list to draw its buttons, so adding an option here is enough.
# yield, military, combat, divisions and allyDefense are fractions (0.25 = +25%). stab and unrest are points on the
# 0-100 meters. Yield, stability, unrest, divisions, combat and military all feed the server's rules now
# (allyDefense is shown but nothing uses it yet, since there are no alliances in battle).
POLICIES = {
    "eco": {"label": "Economic", "options": [
        {"id": "free_market", "name": "Free Market", "desc": "+25% yield, +5 unrest volatility", "yield": 0.25, "unrest": 5},
        {"id": "balanced", "name": "Balanced", "desc": "+10% yield, +5 stability", "yield": 0.10, "stab": 5},
        {"id": "state_command", "name": "State Command", "desc": "+25% military output, -10% yield", "military": 0.25, "yield": -0.10},
    ]},
    "mil": {"label": "Military Doctrine", "options": [
        {"id": "volunteer", "name": "Volunteer", "desc": "+15% combat efficiency", "combat": 0.15},
        {"id": "conscription", "name": "Forced Conscription", "desc": "+40% more divisions, +20% unrest", "divisions": 0.40, "unrest": 20},
    ]},
    "dip": {"label": "Diplomatic Stance", "options": [
        {"id": "neutral", "name": "Neutral", "desc": "No bonuses or penalties."},
        {"id": "interventionism", "name": "Global Interventionism", "desc": "+25% defense power to allies", "allyDefense": 0.25},
        {"id": "isolated", "name": "Isolated", "desc": "Immune to spies", "spyImmune": True},
    ]},
    "gov": {"label": "Government System", "options": [
        {"id": "dictatorship", "name": "Dictatorship", "desc": "A title for now. No bonuses yet."},
        {"id": "socialist", "name": "Socialist", "desc": "A title for now. No bonuses yet."},
        {"id": "democracy", "name": "Democracy", "desc": "A title for now. No bonuses yet."},
        {"id": "communism", "name": "Communism", "desc": "A title for now. No bonuses yet."},
        {"id": "monarchy", "name": "Monarchy", "desc": "A title for now. No bonuses yet."},
    ]},
}

# --- Website casino, daily and the Mayor ----------------------------------------
COINFLIP_PAYOUT = 0.9           # a won coin flip pays this much profit per medal bet (total back = 1.9x). /coinflip uses it too
WEB_MIN_BET = DICE_MIN_BET      # smallest bet on the website's Coin Flip and Blackjack (the page says 100 M for every game)
BJ_TIMEOUT = 5 * 60             # seconds before an abandoned website blackjack hand is stood automatically
MAYOR_SALARY = 12_500           # paid by /mayor salary and shown on the website

# --- Virtual Earth: buildings, military, wars and diplomacy -----------------------
# Every number below is enforced on the server. The website only draws what the server sends.
EARTH_START = {"gdp": 3.0, "pop": 40, "div": 1, "reserve": 2}   # what a freshly claimed nation starts with
GDP_GROWTH_PER_HOUR = 0.0001    # passive GDP growth (0.01% per hour)
TAX_DEFAULT = 15                # national tax (%). At this rate tax changes nothing, so older lands keep their old yield
TAX_MAX_NATION = 40             # highest national tax a ruler can set
TAX_YIELD_PER_POINT = 0.01      # every point of tax above/below the default moves yield by this much (0.01 = 1%)
TAX_STAB_PER_POINT = 0.75       # ...and moves stability by this many points the other way
TAX_UNREST_PER_POINT = 0.5      # every point of tax ABOVE the default adds this much civil unrest
BUILD_COST_STEP = 0.6           # a building's next level costs (1 + level * this) times its base cost
HOSPITAL_UNREST = 3             # unrest removed by each hospital level
SCHOOL_STAB = 2                 # stability added by each school or hospital level
CORE_YIELD_BONUS = 0.20         # the Automated Mega-Industrial Core adds this to every building's yield
COST_FAST = 30_000              # fast-track tech: GDP +3%
COST_STIM = 20_000              # stimulate growth: GDP +2%, +4 citizens
COST_RIOT = 10_000              # quell unrest: unrest -8, stability +2
COST_SWEEP = 10_000             # counter-intelligence sweep
COST_DOSSIER = 30_000           # buy a dossier on another ruler
COST_OPERATIVE = 40_000         # recruit a field operative
OPERATIVE_MAX = 6
SWEEP_BASE = 0.45               # chance a sweep catches an infiltrator, +3% per bunker level, +15% with the Cyber citadel
RECRUIT_COST = 25_000           # per division (it also uses RECRUIT_POP citizens)
RECRUIT_POP = 5
UNIT_COST = {"tanks": 200_000, "jets": 350_000, "ships": 300_000}
COMMAND_SEATS = ("army", "dip", "fin", "spy")
COMMANDER_ACCEPT_SECONDS = 3    # commanders are staff the game hires for you. They accept after this long
DOSSIER_KEEP = 8                # dossiers a nation remembers
WAR_HOURS = 48                  # a war ends in a stalemate after this long
WAR_STEP = 10                   # front progress (out of 100) one reinforcement is worth at equal strength
WAR_SPOILS = 150_000            # what a victor takes from the loser's treasury (never more than it holds)
WAR_SURRENDER_FEE = 50_000      # what a surrendering nation pays the other side (never more than it holds)
TRADE_TARIFF = 85_000           # medals per day, paid to BOTH nations of an active sealane
TRADE_MAX_LANES = 3             # sealanes + open proposals one nation can have. Lanes pay both sides, so keep this small
OFFER_HOURS = 24                # how long a buyout or sealane proposal waits for an answer
COALITIONS = ["Non-aligned", "Northern Pact", "Atlantic League", "Free Ports Union"]
NPC_NAMES = ["Ardent Voss", "Kira Lund", "Maro Tek", "Ilya Brandt", "Sable Quinn", "Tove Harlan"]
OPERATIVE_SPECS = ["Infiltration", "Sabotage", "Cyber warfare"]
# yld = medals/hour added per level, pw = attack power per level, df = defense power per level
BUILDINGS = [
    {"id": "bunker", "name": "Fortified Citadel Bunker and SAM Array", "cost": 300_000, "yld": 2_000, "pw": 10, "df": 65},
    {"id": "mine", "name": "Sovereign Gold and Mineral Mine", "cost": 400_000, "yld": 8_500, "pw": 0, "df": 0},
    {"id": "ind", "name": "Heavy Industrial Complex and Yard", "cost": 350_000, "yld": 7_000, "pw": 25, "df": 15},
    {"id": "hosp", "name": "Regional Hospital and Medical Complex", "cost": 150_000, "yld": 3_000, "pw": 0, "df": 0},
    {"id": "port", "name": "Deepwater Commercial and Naval Port", "cost": 400_000, "yld": 12_000, "pw": 15, "df": 25},
    {"id": "off", "name": "Offshore Sovereign Base", "cost": 650_000, "yld": 4_000, "pw": 45, "df": 55},
    {"id": "oil", "name": "Offshore and Inland Petroleum Rig", "cost": 450_000, "yld": 16_000, "pw": 0, "df": 0},
    {"id": "school", "name": "Public School and University Campus", "cost": 150_000, "yld": 2_500, "pw": 0, "df": 0},
]
# One-off purchases. atk/df add to war power. "core" also adds CORE_YIELD_BONUS to every building's yield.
ARSENAL = [
    {"id": "sat", "name": "Orbital Reconnaissance Satellite Grid", "cost": 250_000, "atk": 40, "df": 35,
     "d": "High-altitude surveillance satellites giving real-time intelligence on foreign military movements.",
     "perk": "+20% infiltration stealth and early attack warnings"},
    {"id": "drone", "name": "Autonomous AI Strike Drone Swarm", "cost": 450_000, "atk": 95, "df": 45,
     "d": "Low-observable loitering munitions for precision strikes on enemy frontline divisions.",
     "perk": "Bypasses 25% of enemy bunker fortifications in wars"},
    {"id": "dome", "name": "Iron Dome and Aegis Ballistic Shield", "cost": 550_000, "atk": 30, "df": 130,
     "d": "Layered air and missile defense intercepting hostile artillery, rockets and saboteurs.",
     "perk": "-50% bombardment damage"},
    {"id": "cyber", "name": "Cyber-Warfare and Jamming Citadel", "cost": 380_000, "atk": 45, "df": 60,
     "d": "Electronic jamming and cyber operations against foreign espionage networks.",
     "perk": "+15% spy capture rate, protects infrastructure from sabotage"},
    {"id": "hyper", "name": "Hypersonic Cruise Missile Battery", "cost": 950_000, "atk": 210, "df": 70,
     "d": "Mach 8+ glide missiles built to crack heavy armor formations and command bastions.",
     "perk": "Devastating frontline offense"},
    {"id": "pad", "name": "Nuclear Launch Pad", "cost": 1_200_000, "atk": 0, "df": 35,
     "d": "Hardened launch infrastructure required before a tactical nuclear weapon can be fired.",
     "perk": "Unlocks one strike per enemy per active war"},
    {"id": "nuke", "name": "Tactical Nuclear Deterrence Complex", "cost": 2_500_000, "atk": 380, "df": 260,
     "d": "Sovereign deterrence silo complex. Hostile invaders face catastrophic retaliation.",
     "perk": "Ultimate deterrence"},
    {"id": "core", "name": "Automated Mega-Industrial Core", "cost": 1_800_000, "atk": 0, "df": 50,
     "d": "Robotic super-factories that fast-track national construction.",
     "perk": "+20% yield from every building"},
]

# --- Website API (leave the env vars unset and the bot runs Discord-only) ---
# DISCORD_CLIENT_ID / DISCORD_CLIENT_SECRET   from the Developer Portal, OAuth2 tab
# WEB_BASE_URL     public URL of this API, e.g. https://api.example.com. Add WEB_BASE_URL/auth/callback
#                  as a Redirect in the Developer Portal.
# SESSION_SECRET   long random string that signs login cookies (python -c "import secrets;print(secrets.token_hex(32))")
# HUB_FILE         the website page this bot serves at "/" (default hub.html next to bot.py).
#                  Serving it from here keeps the page and the API on one origin, which login needs.
# WEB_ORIGIN       (optional) only if the page is hosted somewhere else AND on the same site (e.g. hub.x.com + api.x.com)
# WEB_HOME         (optional) where to send people after login, defaults to WEB_ORIGIN or /
# WEB_HOST/WEB_PORT  defaults 127.0.0.1 / 8080 (put a reverse proxy with HTTPS in front)
CLIENT_ID = os.environ.get("DISCORD_CLIENT_ID", "")
CLIENT_SECRET = os.environ.get("DISCORD_CLIENT_SECRET", "")
WEB_BASE_URL = os.environ.get("WEB_BASE_URL", "").rstrip("/")
SESSION_SECRET = os.environ.get("SESSION_SECRET", "")
WEB_ORIGIN = os.environ.get("WEB_ORIGIN", "").rstrip("/")
WEB_HOME = os.environ.get("WEB_HOME") or WEB_ORIGIN or "/"
HUB_FILE = os.environ.get("HUB_FILE", "hub.html")
WEB_HOST = os.environ.get("WEB_HOST") or ("0.0.0.0" if os.environ.get("PORT") else "127.0.0.1")
WEB_PORT = int(os.environ.get("WEB_PORT") or os.environ.get("PORT") or "8080")
WEB_ENABLED = bool(CLIENT_ID and CLIENT_SECRET and WEB_BASE_URL and len(SESSION_SECRET) >= 16)
SESSION_DAYS = 7
RATE_WRITES = (8, 10)           # at most 8 trades/admin actions per 10 seconds per member
RATE_READS = (40, 10)
# (vault capacity, cost to reach that tier). Capacity is also the most that
# can earn interest, so it is the "daily interest cap".
TIERS = [
    (1_000, 0),
    (10_000, 5_000),
    (50_000, 25_000),
    (100_000, 75_000),
    (250_000, 200_000),
    (500_000, 450_000),
    (1_000_000, 900_000),
]

# ---------------------------------------------------------------------------
# Flavour text. Add your own lines, the bot picks one at random.
# ---------------------------------------------------------------------------
DAILY_LINES = [
    "Fresh medals, still warm from the mint.",
    "The clan treasurer slides an envelope across the table.",
    "You found a pouch of medals wedged under the couch cushions.",
    "A grateful citizen tips their hat and pays up.",
    "The Mayor's office cut you a little something.",
]
WEEKLY_LINES = [
    "A crate lands on your doorstep with the clan seal on it.",
    "The weekly caravan arrives, heavy with medals.",
    "Payday! The treasurer actually remembered you this time.",
    "You cracked open the weekly strongbox and it glittered.",
]
CRIME_WIN = [
    "You pulled off a daring art heist under the moonlight",
    "You hacked the casino's loyalty program and cashed out",
    "You smuggled a crate of rare medals past customs",
    "You ran a fake charity raffle and nobody asked questions",
]
CRIME_LOSE = [
    "The police caught you red-handed",
    "Your getaway driver ditched you at the worst moment",
    "The vault was a decoy and the alarms went off",
    "A rival gang ambushed you in the alley",
]
WORK_LINES = [
    "You pulled a double shift at the medal foundry.",
    "You delivered parcels across town until your feet gave out.",
    "You fixed the town clock tower and the Mayor's office paid up.",
    "You ran the night market stall and counted a decent take.",
    "You guarded the treasury caravan and nothing went wrong, for once.",
    "You stacked crates at the docks from dawn till noon.",
]

# (question, correct answer, [three wrong answers])
TRIVIA = [
    ("What is the capital of Australia?", "Canberra", ["Sydney", "Melbourne", "Perth"]),
    ("Which planet is known as the Red Planet?", "Mars", ["Venus", "Jupiter", "Mercury"]),
    ("What is the chemical symbol for gold?", "Au", ["Ag", "Go", "Gd"]),
    ("Who painted the Mona Lisa?", "Leonardo da Vinci", ["Michelangelo", "Raphael", "Vincent van Gogh"]),
    ("What is the largest ocean on Earth?", "Pacific Ocean", ["Atlantic Ocean", "Indian Ocean", "Arctic Ocean"]),
    ("How many continents are there?", "7", ["5", "6", "8"]),
    ("What is the hardest natural substance?", "Diamond", ["Quartz", "Steel", "Topaz"]),
    ("In which year did World War II end?", "1945", ["1939", "1943", "1950"]),
    ("What is the smallest prime number?", "2", ["0", "1", "3"]),
    ("Who wrote Romeo and Juliet?", "William Shakespeare", ["Charles Dickens", "Jane Austen", "Mark Twain"]),
    ("What is the largest mammal?", "Blue whale", ["African elephant", "Great white shark", "Giraffe"]),
    ("Which gas do plants absorb from the air for photosynthesis?", "Carbon dioxide", ["Oxygen", "Nitrogen", "Helium"]),
    ("What is the capital of Japan?", "Tokyo", ["Kyoto", "Osaka", "Seoul"]),
    ("At sea level, what is the boiling point of water in Celsius?", "100", ["90", "110", "212"]),
    ("How many sides does a hexagon have?", "6", ["5", "7", "8"]),
    ("What is the currency of Japan?", "Yen", ["Won", "Yuan", "Ringgit"]),
    ("Who is considered the national hero of the Philippines?", "Jose Rizal", ["Andres Bonifacio", "Emilio Aguinaldo", "Apolinario Mabini"]),
    ("What is the capital of the Philippines?", "Manila", ["Cebu City", "Davao City", "Quezon City"]),
    ("Which planet is famous for its prominent rings?", "Saturn", ["Mars", "Neptune", "Mercury"]),
    ("What is the largest planet in our solar system?", "Jupiter", ["Saturn", "Earth", "Neptune"]),
    ("Who developed the theory of general relativity?", "Albert Einstein", ["Isaac Newton", "Niels Bohr", "Galileo Galilei"]),
    ("How many bones does an adult human body have?", "206", ["186", "212", "300"]),
    ("What is the tallest mountain above sea level?", "Mount Everest", ["K2", "Mount Kilimanjaro", "Mount Fuji"]),
    ("Which element has the atomic number 1?", "Hydrogen", ["Helium", "Oxygen", "Carbon"]),
    ("Who wrote the novel 1984?", "George Orwell", ["Aldous Huxley", "Ray Bradbury", "H. G. Wells"]),
    ("What is the capital of Canada?", "Ottawa", ["Toronto", "Vancouver", "Montreal"]),
    ("Which vitamin does your skin produce when exposed to sunlight?", "Vitamin D", ["Vitamin A", "Vitamin C", "Vitamin K"]),
    ("Which ancient wonder of the world is still standing?", "Great Pyramid of Giza", ["Hanging Gardens of Babylon", "Colossus of Rhodes", "Lighthouse of Alexandria"]),
    ("Which country gave the Statue of Liberty to the United States?", "France", ["England", "Spain", "Italy"]),
    ("Who is credited with inventing the telephone?", "Alexander Graham Bell", ["Thomas Edison", "Nikola Tesla", "Guglielmo Marconi"]),
    ("What is the smallest country in the world by area?", "Vatican City", ["Monaco", "San Marino", "Liechtenstein"]),
    ("Which is the only mammal capable of true sustained flight?", "Bat", ["Flying squirrel", "Sugar glider", "Ostrich"]),
    ("What is the fastest land animal?", "Cheetah", ["Lion", "Greyhound", "Pronghorn antelope"]),
    ("What is the binary number 101 in decimal?", "5", ["3", "6", "7"]),
    ("Who discovered penicillin?", "Alexander Fleming", ["Louis Pasteur", "Marie Curie", "Joseph Lister"]),
    ("What is the square root of 144?", "12", ["10", "14", "16"]),
    ("Which planet is closest to the Sun?", "Mercury", ["Venus", "Earth", "Mars"]),
]

BJ_BUST = ["Too greedy!", "Over the line!", "The cards turned on you."]
BJ_WIN = ["Beautiful hand!", "The dealer sweats.", "Read them like a book."]
BJ_LOSE = ["The house always smiles last.", "So close.", "Shuffle up and try again."]

# ---------------------------------------------------------------------------
# Tiny JSON "database" (fine to start; move to a real DB when you add the API)
# ---------------------------------------------------------------------------
if os.path.exists(DB_FILE):
    with open(DB_FILE, encoding="utf-8") as f:
        db = json.load(f)
else:
    db = {}
if "users" not in db:           # upgrade data.json from the first version
    db = {"users": db}
db.setdefault("election", None)
db.setdefault("mayor", None)
db.setdefault("announce_channel", None)
db.setdefault("tax", DEFAULT_TAX)   # market tax (%) applied to /transfer and stock trades
db.setdefault("earth", {})          # claimed lands: {"DE": {"owner": "<member id>", "name": "...", "at": unix_seconds, "nation": {...}}}
db.setdefault("market_bank", {"balance": 0, "in": {"transfer": 0, "stock": 0}, "log": []})   # where tax and fees go
db.setdefault("wars", [])           # Virtual Earth wars: {"id", "a", "b", "prog", "started", "ends"}  (a attacks b)
db.setdefault("lanes", [])          # active sealanes: {"id", "a", "b", "since", "last"}
db.setdefault("offers", [])         # buyout offers (the money is held here) and sealane proposals
db.setdefault("bj", {})             # website blackjack hands in progress, so a restart never eats a bet

# Stocks: {"WHY": {"name", "price", "base", "avail", "hist": [[unix_seconds, price], ...]}}
# Only seeded when the key is missing, so delisting everything never brings them back.
if "stocks" not in db:
    db["stocks"] = {
        t: {"name": n, "price": float(p), "base": float(p), "avail": 2_500,
            "hist": [[time.time(), float(p)]]}
        for t, n, p in STOCK_SEEDS
    }
db.setdefault("stock_meta", {"last_div": time.time()})
for _s in db["stocks"].values():
    _s.setdefault("base", _s["price"])


def lift_old_stock_prices():
    """Runs once per data.json. Any stock whose base price is under STOCK_MIN_BASE is scaled up, and its
    history and every holder's average cost scale with it, so profit/loss and charts keep their shape.
    Known tickers go to their STOCK_SEEDS price; any other gets a spread between 2k and about 21k."""
    meta = db["stock_meta"]
    if meta.get("lifted"):
        return
    seed = {t: p for t, _, p in STOCK_SEEDS}
    for t, s in db["stocks"].items():
        if s["base"] >= STOCK_MIN_BASE:
            continue
        target = float(seed.get(t) or STOCK_MIN_BASE * (1 + zlib.crc32(t.encode()) % 40 / 4))
        f = target / s["base"]
        s["price"] *= f
        s["base"] = target
        for point in s["hist"]:
            point[1] *= f
        for u in db["users"].values():
            h = u.get("holdings", {}).get(t)
            if h:
                h["avg"] *= f
    meta["lifted"] = True


lift_old_stock_prices()

DEFAULTS = {
    "medals": 0, "streak": 0, "last_daily": 0, "last_salary": 0,
    "last_crime": 0, "last_rob": 0, "last_weekly": 0, "weekly_streak": 0,
    "bank": None, "last_work": 0, "last_trivia": 0,
}


def save():
    # write to a temp file and swap it in, so a crash mid-write can't corrupt data.json
    tmp = DB_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(db, f, indent=2)
    os.replace(tmp, DB_FILE)


def get_user(uid):
    u = db["users"].setdefault(str(uid), {})
    for key, value in DEFAULTS.items():
        u.setdefault(key, value)
    u.setdefault("holdings", {})    # its own line: a {} in DEFAULTS would be shared by every user
    u.setdefault("gamble", {"won": 0, "lost": 0})   # casino totals for the website's Best Gambler board
    return u


def total_medals(u):
    return u["medals"] + (u["bank"]["vault"] if u.get("bank") else 0)


def record_gamble(u, profit):
    """Keeps running casino totals: 'won' is profit from winning games, 'lost' is stakes lost.
    Net = won - lost. A push (profit 0) changes nothing."""
    g = u["gamble"]
    if profit > 0:
        g["won"] += profit
    elif profit < 0:
        g["lost"] -= profit


# ---------------------------------------------------------------------------
# Pretty-printing helpers
# ---------------------------------------------------------------------------
COLORS = {
    "ok": 0x57F287,      # green
    "bad": 0xED4245,     # red
    "info": 0xA66BFF,    # purple
    "gold": 0xF4C95D,    # gold
    "warn": 0xF4A94E,    # orange
}


def ts(seconds):
    """Discord countdown, e.g. 'in 3 hours'."""
    return f"<t:{int(seconds)}:R>"


def meter(current, total, width=10):
    filled = 0 if total <= 0 else max(0, min(width, round(width * current / total)))
    return "█" * filled + "░" * (width - filled)


def streak_bar(streak, length=7):
    pos = streak % length or length
    return "▰" * pos + "▱" * (length - pos)


def make_embed(title, desc=None, kind="info", fields=None, footer=None):
    e = discord.Embed(title=title, description=desc, colour=COLORS[kind])
    for name, value, inline in fields or []:
        e.add_field(name=name, value=value, inline=inline)
    if footer:
        e.set_footer(text=footer)
    return e


async def say(interaction, title, desc=None, kind="info", *, ephemeral=False,
              fields=None, footer=None, content=None, view=None):
    kwargs = {"embed": make_embed(title, desc, kind, fields, footer), "ephemeral": ephemeral}
    if content:
        kwargs["content"] = content
    if view is not None:
        kwargs["view"] = view
    await interaction.response.send_message(**kwargs)


async def follow(interaction, title, desc=None, kind="info", *, fields=None, footer=None):
    await interaction.followup.send(embed=make_embed(title, desc, kind, fields, footer))


async def deny(interaction, text):
    await say(interaction, "⛔ Hold up", text, "bad", ephemeral=True)


async def cooldown(interaction, title, ready_at):
    await say(interaction, title, f"Ready again {ts(ready_at)}.", "warn", ephemeral=True)


# ---------------------------------------------------------------------------
# Permission helpers
# ---------------------------------------------------------------------------
def is_owner(interaction):
    return interaction.user.id == interaction.guild.owner_id


def is_admin(interaction):
    return interaction.user.guild_permissions.administrator


def is_staff(interaction):
    p = interaction.user.guild_permissions
    return (
        p.administrator
        or p.manage_guild
        or any(r.name == STAFF_ROLE for r in interaction.user.roles)
    )


def is_mayor(interaction):
    return any(r.name == MAYOR_ROLE for r in getattr(interaction.user, "roles", []))


# ---------------------------------------------------------------------------
# Bank helpers
# ---------------------------------------------------------------------------
def hash_pw(password, salt_hex):
    return hashlib.pbkdf2_hmac(
        "sha256", password.encode(), bytes.fromhex(salt_hex), 100_000
    ).hex()


def make_bank(password):
    salt = secrets.token_hex(16)
    return {
        "salt": salt, "hash": hash_pw(password, salt), "vault": 0, "tier": 0,
        "loan": 0, "due": 0, "penalized": False, "last_interest": time.time(),
    }


def check_pw(bank, guess):
    return hmac.compare_digest(bank["hash"], hash_pw(guess, bank["salt"]))


def vault_cap(bank):
    return TIERS[bank["tier"]][0]


def refresh_bank(bank):
    """Apply daily interest and the late-loan penalty."""
    now = time.time()
    days = int((now - bank["last_interest"]) // DAY)
    if days > 0:
        for _ in range(min(days, 60)):
            bank["vault"] = min(
                vault_cap(bank), bank["vault"] + int(bank["vault"] * DAILY_INTEREST)
            )
        bank["last_interest"] += days * DAY
    if bank["loan"] > 0 and not bank["penalized"] and now > bank["due"]:
        bank["loan"] += int(bank["loan"] * LOAN_FEE)
        bank["penalized"] = True


async def need_bank(interaction):
    me = get_user(interaction.user.id)
    if not me["bank"]:
        await deny(interaction, "You don't have a bank account yet. Open one with `/bank create`.")
        return None, None
    refresh_bank(me["bank"])
    return me, me["bank"]


# ---------------------------------------------------------------------------
# Mayor / election helpers
# ---------------------------------------------------------------------------
async def get_mayor_role(guild):
    role = discord.utils.get(guild.roles, name=MAYOR_ROLE)
    if role is None:
        role = await guild.create_role(
            name=MAYOR_ROLE, colour=discord.Colour.gold(), reason="Mayor role"
        )
    return role


async def clear_mayor(guild):
    old = db["mayor"]
    db["mayor"] = None
    db["tax"] = DEFAULT_TAX
    save()
    if old:
        role = discord.utils.get(guild.roles, name=MAYOR_ROLE)
        if role:
            try:
                member = await guild.fetch_member(old["id"])
                await member.remove_roles(role)
            except discord.HTTPException:
                pass


async def set_mayor(guild, member):
    role = await get_mayor_role(guild)
    old = db["mayor"]
    if old and old["id"] != member.id:
        try:
            previous = await guild.fetch_member(old["id"])
            await previous.remove_roles(role)
        except discord.HTTPException:
            pass
    await member.add_roles(role)
    db["mayor"] = {"id": member.id, "term_end": time.time() + TERM_DAYS * DAY}
    db["tax"] = DEFAULT_TAX
    save()


def tally(el):
    counts = {cid: 0 for cid in el["candidates"]}
    for v in el["votes"].values():
        key = str(v["cand"])
        if key in counts:
            counts[key] += 1
    return counts


async def conclude_election(guild):
    """Ends the election and returns an embed announcing the result."""
    el = db["election"]
    db["election"] = None
    counts = tally(el)
    if not counts or max(counts.values()) == 0:
        save()
        return make_embed(
            "🗳️ The polls are closed",
            "Nobody cast a ballot, so no Mayor was chosen this time.",
            "warn",
        )
    # most votes wins; a tie goes to whoever registered first
    winner = max(counts, key=lambda c: (counts[c], -el["candidates"][c]["registered"]))
    results = "\n".join(
        f"{'🥇' if c == winner else '▫️'} <@{c}>: **{n}** vote(s)"
        for c, n in sorted(counts.items(), key=lambda kv: -kv[1])
    )
    try:
        member = await guild.fetch_member(int(winner))
        await set_mayor(guild, member)
    except discord.HTTPException as e:
        save()
        return make_embed(
            "🗳️ We have a winner, but...",
            f"<@{winner}> won, but I couldn't give them the **{MAYOR_ROLE}** role ({e}).\n"
            f"Check that my role has *Manage Roles* and sits above the {MAYOR_ROLE} role.\n\n{results}",
            "warn",
        )
    save()
    return make_embed(
        "👑 Long live the new Mayor!",
        f"<@{winner}> takes office with **{counts[winner]}** vote(s).",
        "gold",
        fields=[("📊 Final results", results, False),
                ("🏛️ Term", f"{TERM_DAYS} days, ends {ts(time.time() + TERM_DAYS * DAY)}", False)],
    )


def flag_votes(el):
    """Rough alt-account heuristics. Always review before purging."""
    flagged = {}
    for voter_id, v in el["votes"].items():
        reasons = []
        if v["t"] - v["acct"] < 7 * DAY:
            reasons.append("Discord account under 7 days old")
        if v["joined"] and v["t"] - v["joined"] < 24 * 3600:
            reasons.append("joined the server less than 24h before voting")
        if reasons:
            flagged[voter_id] = reasons
    return flagged


async def open_election(interaction):
    el = db["election"]
    if not el or time.time() >= el["ends"]:
        await deny(interaction, "There's no open election right now.")
        return None
    return el


# ---------------------------------------------------------------------------
# Stock market logic
# Plain functions, shared by the Discord commands and the website API. None of
# them awaits, so a check and the write that follows it can never be split by
# another request (no double spending). Each one validates first, then writes.
# ---------------------------------------------------------------------------
class TradeError(Exception):
    """A rule was broken. The message is safe to show the member."""


TICKER_RE = re.compile(r"[A-Z]{2,6}")


def find_stock(ticker):
    t = ticker.strip().upper() if isinstance(ticker, str) else ""
    s = db["stocks"].get(t)
    if s is None:
        raise TradeError("There's no stock with that ticker.")
    return t, s


def whole(value, name, lo, hi):
    """Strict whole-number check for anything that came from a client."""
    if isinstance(value, str) and value.isascii() and value.isdigit():
        value = int(value)
    if isinstance(value, bool) or not isinstance(value, int) or not lo <= value <= hi:
        raise TradeError(f"{name} must be a whole number from {lo:,} to {hi:,}.")
    return value


def number(value, name, lo, hi):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) \
            or not lo <= value <= hi:
        raise TradeError(f"{name} must be a number from {lo:,} to {hi:,}.")
    return float(value)


def fee_rate():
    return max(db["tax"], STOCK_MIN_FEE)


def bank_collect(kind, amount):
    """Tax and trading fees land in the Market Bank. kind is 'transfer' or 'stock'."""
    if not TAX_TO_MARKET_BANK or amount <= 0:
        return
    b = db["market_bank"]
    b["balance"] += amount
    b["in"][kind] = b["in"].get(kind, 0) + amount


def pay_fee(fee):
    bank_collect("stock", fee)


def record_price(s, now=None):
    s["hist"].append([now or time.time(), s["price"]])
    del s["hist"][:-STOCK_HIST_POINTS]


def impact(n):
    return min(STOCK_IMPACT_CAP, n / STOCK_SUPPLY * STOCK_IMPACT_RATE)


def buy_shares(uid, ticker, qty):
    t, s = find_stock(ticker)
    n = whole(qty, "Quantity", 1, STOCK_MAX_PER_MEMBER)
    me = get_user(uid)
    h = me["holdings"].get(t) or {"q": 0, "avg": 0.0}
    if h["q"] + n > STOCK_MAX_PER_MEMBER:
        raise TradeError(f"You can hold at most {STOCK_MAX_PER_MEMBER} shares of {t} "
                         f"(you have {h['q']}).")
    if n > s["avail"]:
        raise TradeError(f"Only {s['avail']:,} shares of {t} are left.")
    rate = fee_rate()
    base = math.ceil(s["price"] * n)
    fee = -(-base * rate // 100)
    total = base + fee
    if total > me["medals"]:
        raise TradeError(f"That costs **{total:,}** M but your wallet has **{me['medals']:,}** M.")
    price = s["price"]
    me["medals"] -= total
    pay_fee(fee)
    h["avg"] = (h["avg"] * h["q"] + price * n) / (h["q"] + n)
    h["q"] += n
    me["holdings"][t] = h
    s["avail"] -= n
    s["price"] = max(STOCK_MIN_PRICE, price * (1 + impact(n)))
    record_price(s)
    save()
    return {"ticker": t, "qty": n, "price": price, "base": base, "fee": fee, "rate": rate,
            "total": total, "wallet": me["medals"], "held": h["q"], "new_price": s["price"]}


def sell_shares(uid, ticker, qty):
    t, s = find_stock(ticker)
    n = whole(qty, "Quantity", 1, STOCK_MAX_PER_MEMBER)
    me = get_user(uid)
    h = me["holdings"].get(t)
    if not h or h["q"] < n:
        raise TradeError(f"You only hold {h['q'] if h else 0} share(s) of {t}.")
    rate = fee_rate()
    base = math.floor(s["price"] * n)
    fee = -(-base * rate // 100)
    net = base - fee
    price = s["price"]
    me["medals"] += net
    pay_fee(fee)
    h["q"] -= n
    if h["q"] == 0:
        del me["holdings"][t]
    s["avail"] += n
    s["price"] = max(STOCK_MIN_PRICE, price * (1 - impact(n)))
    record_price(s)
    save()
    return {"ticker": t, "qty": n, "price": price, "base": base, "fee": fee, "rate": rate,
            "total": net, "wallet": me["medals"], "held": h["q"], "new_price": s["price"]}


def found_company(uid, name, ticker, valuation, revenue, profit):
    """The hub decided this in the browser with Math.random(). Now only the server does."""
    name = name.strip() if isinstance(name, str) else ""
    if not 2 <= len(name) <= 40 or not name.isprintable():
        raise TradeError("The company name must be 2 to 40 characters.")
    t = ticker.strip().upper() if isinstance(ticker, str) else ""
    if not TICKER_RE.fullmatch(t):
        raise TradeError("The ticker must be 2 to 6 letters.")
    val = number(valuation, "Valuation", 0, 1e12)
    rev = number(revenue, "Revenue", 0, 1e12)
    prof = number(profit, "Profit", -1e12, 1e12)
    if t in db["stocks"]:
        raise TradeError("That ticker is taken.")
    if len(db["stocks"]) >= STOCK_MAX_LISTED:
        raise TradeError(f"The exchange is full ({STOCK_MAX_LISTED} listings).")
    me = get_user(uid)
    if me["medals"] < STOCK_FOUND_COST:
        raise TradeError(f"Founding a company costs {STOCK_FOUND_COST:,} M.")
    me["medals"] -= STOCK_FOUND_COST
    plausible = val <= max(rev * 4, 1) + max(prof * 12, 0) + 200_000
    approved = plausible and random.random() < 0.5
    fair = val if approved else max(100_000, val * 0.35)
    price = max(STOCK_MIN_BASE, fair / STOCK_SUPPLY)
    db["stocks"][t] = {"name": name, "price": price, "base": price, "avail": STOCK_SUPPLY,
                       "hist": [[time.time(), price]],
                       "note": "" if approved else "AI review: crash-adjusted"}
    save()
    return {"ticker": t, "name": name, "approved": approved, "price": price, "wallet": me["medals"]}


def set_stock_price(ticker, price):
    t, s = find_stock(ticker)
    p = number(price, "Price", STOCK_MIN_PRICE, 1e9)
    old = s["price"]
    s["price"] = s["base"] = p      # base moves too, or the market would pull it straight back
    record_price(s)
    save()
    return {"ticker": t, "old": old, "price": p}


def delist_stock(ticker):
    t, s = find_stock(ticker)
    if len(db["stocks"]) < 2:
        raise TradeError("At least one stock must stay listed.")
    refunded = holders = 0
    for u in db["users"].values():
        h = u.get("holdings", {}).pop(t, None)
        if h and h["q"] > 0:
            amount = math.floor(h["q"] * s["price"])
            u["medals"] += amount
            refunded += amount
            holders += 1
    del db["stocks"][t]
    save()
    return {"ticker": t, "holders": holders, "refunded": refunded}


def tick_prices(now=None):
    """One step of the random walk for every stock."""
    now = now or time.time()
    for s in db["stocks"].values():
        drift = (random.random() - 0.5) * STOCK_DRIFT
        if random.random() < STOCK_CRASH_CHANCE:
            drift -= STOCK_CRASH_SIZE
        if STOCK_CRASH_COMPENSATE:
            drift += STOCK_CRASH_CHANCE * STOCK_CRASH_SIZE
        drift += STOCK_REVERT * math.log(s["base"] / s["price"])
        s["price"] = max(STOCK_MIN_PRICE, s["price"] * (1 + drift))
        record_price(s, now)


def pay_dividends(now=None):
    """Lazy, like the bank: pays for each whole hour since last time, so a restart never skips or doubles."""
    meta = db["stock_meta"]
    now = now or time.time()
    hours = int((now - meta["last_div"]) // STOCK_DIV_INTERVAL)
    if hours < 1:
        return 0
    meta["last_div"] += hours * STOCK_DIV_INTERVAL
    hours = min(hours, STOCK_DIV_CATCHUP)
    paid = 0
    for u in db["users"].values():
        per_hour = sum(
            math.floor(h["q"] * db["stocks"][t]["price"] * STOCK_DIVIDEND)
            for t, h in u.get("holdings", {}).items() if t in db["stocks"]
        )
        u["medals"] += per_hour * hours
        paid += per_hour * hours
    save()
    return paid


def stock_open(s):
    return s["hist"][0][1]


def stock_change(s):
    return (s["price"] / stock_open(s) - 1) * 100


def stocks_json():
    return [
        {"t": t, "name": s["name"], "price": s["price"], "open": stock_open(s), "avail": s["avail"],
         "note": s.get("note", ""),
         "hist": [{"t": int(ts_ * 1000), "p": p} for ts_, p in s["hist"]]}
        for t, s in db["stocks"].items()
    ]


def holdings_json(uid):
    return {t: {"q": h["q"], "avg": h["avg"]}
            for t, h in get_user(uid)["holdings"].items() if t in db["stocks"]}


# ---------------------------------------------------------------------------
# Market Bank, dice and Virtual Earth logic
# Plain functions like the stock ones above: no await, validate first, then write.
# ---------------------------------------------------------------------------
def wait_text(seconds):
    seconds = max(1, int(seconds))
    if seconds >= 3600:
        return f"{seconds // 3600}h {seconds % 3600 // 60}m"
    if seconds >= 60:
        return f"{seconds // 60}m"
    return f"{seconds}s"


def can_use_market_bank(member, guild):
    """Mayor, server Owner, Administrators and the staff roles."""
    if member.id == guild.owner_id or member.guild_permissions.administrator:
        return True
    mayor_state = db["mayor"]
    if mayor_state and mayor_state["id"] == member.id:
        return True
    return any(r.name in STAFF_ROLE or r.name == MAYOR_ROLE for r in member.roles)


def market_bank_json():
    b = db["market_bank"]
    return {
        "balance": int(b["balance"]),
        "in": {"transfer": int(b["in"].get("transfer", 0)), "stock": int(b["in"].get("stock", 0))},
        "tax": db["tax"],
        "log": [{"kind": e["kind"], "name": e["name"], "amount": e["amount"], "t": e["t"]}
                for e in reversed(b["log"][-10:])],
    }


def market_bank_move(uid, name, kind, amount):
    """kind is 'withdraw' (bank -> wallet) or 'deposit' (wallet -> bank)."""
    amount = whole(amount, "Amount", 1, 1_000_000_000)
    me = get_user(uid)
    b = db["market_bank"]
    if kind == "withdraw":
        if amount > b["balance"]:
            raise TradeError(f"The Market Bank only holds {b['balance']:,} M.")
        b["balance"] -= amount
        me["medals"] += amount
    else:
        if amount > me["medals"]:
            raise TradeError(f"You only have {me['medals']:,} M in your wallet.")
        me["medals"] -= amount
        b["balance"] += amount
    b["log"].append({"kind": kind, "uid": str(uid), "name": name, "amount": amount, "t": int(time.time() * 1000)})
    del b["log"][:-MARKET_BANK_LOG]
    save()
    return {**market_bank_json(), "wallet": me["medals"]}


def play_dice(uid, bet):
    """Two dice each. Beat the house total to win 2x (profit = the bet). A tie goes to the house."""
    bet = whole(bet, "Bet", DICE_MIN_BET, 1_000_000_000)
    me = get_user(uid)
    if bet > me["medals"]:
        raise TradeError(f"You only have **{me['medals']:,}** M in your wallet.")
    you = [random.randint(1, 6), random.randint(1, 6)]
    house = [random.randint(1, 6), random.randint(1, 6)]
    if sum(you) > sum(house):
        result, net = "win", bet
    else:
        result, net = ("tie" if sum(you) == sum(house) else "loss"), -bet
    me["medals"] += net
    record_gamble(me, net)
    save()
    return {"you": you, "house": house, "result": result, "net": net, "bet": bet, "wallet": me["medals"]}


# --- Virtual Earth: treasury, yield and policies ---
def policy_option(cat, value):
    spec = POLICIES.get(cat) if isinstance(cat, str) else None
    if spec is None or not isinstance(value, str):
        return None
    return next((o for o in spec["options"] if o["id"] == value), None)


def nation_state(land):
    """The economy of one claimed land. Lands claimed before a field existed get it the first time they are looked at."""
    now = time.time()
    n = land.get("nation")
    if n is None:
        n = land["nation"] = {"treasury": 0, "pending": 0.0, "pend_at": now, "policy": {}, "ready": {}}
    for cat, default in DEFAULT_POLICY.items():
        if policy_option(cat, n["policy"].get(cat)) is None:
            n["policy"][cat] = default
    n.setdefault("gdp", float(EARTH_START["gdp"]))
    n.setdefault("pop", EARTH_START["pop"])
    n.setdefault("div", EARTH_START["div"])
    n.setdefault("reserve", EARTH_START["reserve"])
    for key in ("tanks", "jets", "ships", "pows", "stab_adj", "relief"):
        n.setdefault(key, 0)
    n.setdefault("tax", TAX_DEFAULT)
    n.setdefault("grown_at", now)
    n.setdefault("lv", {})
    n.setdefault("ars", {})
    n.setdefault("ops", [])
    n.setdefault("dossiers", [])
    n.setdefault("coal", COALITIONS[0])
    cmd = n.setdefault("cmd", {})
    for seat in COMMAND_SEATS:
        cmd.setdefault(seat, None)
    return n


def policy_fx(policy):
    fx = {"yield": 0.0, "stab": 0, "unrest": 0, "military": 0.0, "combat": 0.0,
          "divisions": 0.0, "allyDefense": 0.0, "spyImmune": False}
    for cat, value in policy.items():
        opt = policy_option(cat, value)
        if not opt:
            continue
        for k in fx:
            if k == "spyImmune":
                fx[k] = fx[k] or bool(opt.get(k))
            else:
                fx[k] += opt.get(k, 0)
    return {k: (round(v, 4) if isinstance(v, float) else v) for k, v in fx.items()}


def land_yield(n):
    """Medals per hour: the land's base, plus its buildings, then the Core, policies and national tax."""
    buildings = sum(b["yld"] * level(n, b["id"]) for b in BUILDINGS)
    if n["ars"].get("core"):
        buildings *= 1 + CORE_YIELD_BONUS
    raw = EARTH_BASE_YIELD + buildings
    raw *= max(0.0, 1 + policy_fx(n["policy"])["yield"])
    raw *= max(0.0, 1 + (n["tax"] - TAX_DEFAULT) * TAX_YIELD_PER_POINT)
    return int(round(raw))


def accrue(n, now):
    """Banks the yield earned since the last time, at the CURRENT rate. Call it before the rate changes."""
    y = land_yield(n)
    room = max(0.0, y * EARTH_CAP_HOURS - n["pending"])
    n["pending"] += min(room, y * max(0.0, now - n["pend_at"]) / 3600)
    n["pend_at"] = now


def owned_codes(uid):
    return [c for c, l in db["earth"].items() if l["owner"] == str(uid) and c in EARTH_NATIONS]


def own_land(uid, code):
    code = code.strip().upper() if isinstance(code, str) else ""
    land = db["earth"].get(code)
    if code not in EARTH_NATIONS or land is None or land["owner"] != str(uid):
        raise TradeError("You don't rule that land.")
    return code, land


def harvest_land(uid, code):
    code, land = own_land(uid, code)
    n = nation_state(land)
    accrue(n, time.time())
    amount = int(n["pending"])
    if amount < 1:
        raise TradeError("There is nothing to harvest yet. Yield builds up every hour.")
    n["pending"] -= amount
    n["treasury"] += amount
    save()
    return {"code": code, "harvested": amount, "treasury": n["treasury"]}


def move_treasury(uid, code, kind, amount):
    """kind is 'deposit' (wallet -> treasury) or 'withdraw' (treasury -> wallet). No fee either way."""
    code, land = own_land(uid, code)
    amount = whole(amount, "Amount", 1, 1_000_000_000)
    n = nation_state(land)
    me = get_user(uid)
    if kind == "deposit":
        if amount > me["medals"]:
            raise TradeError(f"You only have {me['medals']:,} M in your wallet.")
        me["medals"] -= amount
        n["treasury"] += amount
    else:
        if amount > n["treasury"]:
            raise TradeError(f"Your treasury only holds {int(n['treasury']):,} M.")
        n["treasury"] -= amount
        me["medals"] += amount
    save()
    return {"code": code, "amount": amount, "treasury": n["treasury"], "wallet": me["medals"]}


def set_policy(uid, code, category, value):
    code, land = own_land(uid, code)
    opt = policy_option(category, value)
    if opt is None:
        raise TradeError("That policy doesn't exist.")
    spec = POLICIES[category]
    n = nation_state(land)
    if n["policy"][category] == value:
        raise TradeError(f"{spec['label']} is already {opt['name']}.")
    now = time.time()
    ready = n["ready"].get(category, 0)
    if ready > now:
        raise TradeError(f"{spec['label']} can change again in {wait_text(ready - now)}.")
    accrue(n, now)                  # what the land earned so far is banked at the old rate
    n["policy"][category] = value
    n["ready"][category] = now + POLICY_COOLDOWN
    save()
    return {"code": code, "name": opt["name"], "desc": opt["desc"], "label": spec["label"]}


# ---------------------------------------------------------------------------
# Wallet, vault, daily and casino for the website
# Plain functions with no await (so a check and the write after it can't be split). They apply the same
# rules as /daily, /bank deposit, /bank withdraw, /coinflip and /blackjack in Discord, on the same wallet.
# ---------------------------------------------------------------------------
def vault_json(me):
    b = me["bank"]
    if not b:
        return None
    refresh_bank(b)
    nxt = TIERS[b["tier"] + 1] if b["tier"] < len(TIERS) - 1 else None
    return {"balance": int(b["vault"]), "cap": vault_cap(b), "tier": b["tier"],
            "loan": int(b["loan"]), "due": int(b["due"] * 1000) if b["loan"] else 0,
            "nextCap": nxt[0] if nxt else None, "nextCost": nxt[1] if nxt else None}


def account_json(uid):
    """Vault and daily-streak numbers for the signed-in member's page."""
    me = get_user(uid)
    alive = time.time() - me["last_daily"] < 2 * DAY      # miss a whole day and the streak is gone
    return {"vault": vault_json(me), "streak": int(me["streak"]) if alive else 0,
            "dailyReadyAt": int((me["last_daily"] + DAY) * 1000), "dailyReward": DAILY_REWARD}


def claim_daily(uid):
    me = get_user(uid)
    now = time.time()
    if now < me["last_daily"] + DAY:
        raise TradeError(f"Daily already claimed. Ready again in {wait_text(me['last_daily'] + DAY - now)}.")
    me["streak"] = me["streak"] + 1 if now - me["last_daily"] < 2 * DAY else 1
    me["last_daily"] = now
    me["medals"] += DAILY_REWARD
    save()
    return {"reward": DAILY_REWARD, "streak": me["streak"], "wallet": me["medals"], "account": account_json(uid)}


def vault_move(uid, kind, amount):
    """kind is 'deposit' (wallet -> vault) or 'withdraw' (vault -> wallet). Accounts are opened in Discord with
    /bank create, so the website never sees a vault password."""
    amount = whole(amount, "Amount", 1, 1_000_000_000)
    me = get_user(uid)
    b = me["bank"]
    if not b:
        raise TradeError("You don't have a bank account yet. Open one with /bank create in Discord.")
    refresh_bank(b)
    if kind == "deposit":
        if amount > me["medals"]:
            raise TradeError(f"You only have {me['medals']:,} M in your wallet.")
        space = vault_cap(b) - b["vault"]
        if amount > space:
            raise TradeError(f"Your vault only has room for {space:,} M. Upgrade it with /bank upgrade.")
        me["medals"] -= amount
        b["vault"] += amount
    else:
        if amount > b["vault"]:
            raise TradeError(f"Your vault only holds {b['vault']:,} M.")
        b["vault"] -= amount
        me["medals"] += amount
    save()
    return {"amount": amount, "wallet": me["medals"], "account": account_json(uid)}


def flip_coin(uid, bet, side):
    bet = whole(bet, "Bet", WEB_MIN_BET, 1_000_000_000)
    side = side.lower() if isinstance(side, str) else ""
    if side not in ("heads", "tails"):
        raise TradeError("Pick heads or tails.")
    me = get_user(uid)
    if bet > me["medals"]:
        raise TradeError(f"You only have {me['medals']:,} M in your wallet.")
    result = random.choice(["heads", "tails"])
    net = int(bet * COINFLIP_PAYOUT) if result == side else -bet
    me["medals"] += net
    record_gamble(me, net)
    save()
    return {"side": side, "result": result, "won": net > 0, "net": net, "bet": bet, "wallet": me["medals"]}


# --- Blackjack. The hand lives in data.json (db["bj"]) so a restart never eats a bet. The deck and the dealer's
# hole card never leave the server. A hand nobody finishes is stood for them after BJ_TIMEOUT, like in Discord.
def bj_json(uid, g, result=None, payout=0):
    done = result is not None
    return {"active": not done, "bet": g["bet"], "player": g["p"], "pv": hand_value(g["p"]),
            "dealer": g["d"] if done else g["d"][:1], "dv": hand_value(g["d"]) if done else None,
            "result": result, "payout": payout, "net": payout - g["bet"] if done else 0,
            "wallet": get_user(uid)["medals"]}


def bj_pay(uid, g, payout, result):
    me = get_user(uid)
    me["medals"] += payout
    record_gamble(me, payout - g["bet"])        # win +bet, push 0, loss -bet
    db["bj"].pop(str(uid), None)
    save()
    return bj_json(uid, g, result, payout)


def bj_finish(uid, g):
    """Dealer plays (unless the player busted) and the bet is settled."""
    pv = hand_value(g["p"])
    if pv <= 21:
        while hand_value(g["d"]) < 17:
            g["d"].append(g["deck"].pop())
    dv = hand_value(g["d"])
    bet = g["bet"]
    if pv > 21:
        return bj_pay(uid, g, 0, "bust")
    if dv > 21 or pv > dv:
        return bj_pay(uid, g, bet * 2, "win")
    if pv == dv:
        return bj_pay(uid, g, bet, "push")
    return bj_pay(uid, g, 0, "loss")


def bj_get(uid):
    g = db["bj"].get(str(uid))
    if g is None:
        raise TradeError("You don't have a hand in play. Place a bet and press Deal.")
    return g


def bj_stale(g):
    return time.time() - g["t"] > BJ_TIMEOUT


def bj_state(uid):
    g = db["bj"].get(str(uid))
    if g is None:
        return {"active": False, "result": None, "wallet": get_user(uid)["medals"]}
    if bj_stale(g):
        return {**bj_finish(uid, g), "timedOut": True}
    return bj_json(uid, g)


def bj_deal(uid, bet):
    bet = whole(bet, "Bet", WEB_MIN_BET, 1_000_000_000)
    me = get_user(uid)
    old = db["bj"].get(str(uid))
    if old is not None:
        if not bj_stale(old):
            raise TradeError("Finish your current hand first.")
        bj_finish(uid, old)
    if bet > me["medals"]:
        raise TradeError(f"You only have {me['medals']:,} M in your wallet.")
    me["medals"] -= bet                         # the bet is held until the hand ends
    deck = [[r, s] for r in RANKS for s in SUITS]
    random.shuffle(deck)
    g = {"bet": bet, "deck": deck, "p": [deck.pop(), deck.pop()], "d": [deck.pop(), deck.pop()], "t": time.time()}
    db["bj"][str(uid)] = g
    if hand_value(g["p"]) == 21:                # natural blackjack
        if hand_value(g["d"]) == 21:
            return bj_pay(uid, g, bet, "push")
        return bj_pay(uid, g, bet + int(bet * 1.5), "blackjack")
    save()
    return bj_json(uid, g)


def bj_hit(uid):
    g = bj_get(uid)
    if bj_stale(g):
        return {**bj_finish(uid, g), "timedOut": True}
    g["p"].append(g["deck"].pop())
    g["t"] = time.time()
    if hand_value(g["p"]) >= 21:
        return bj_finish(uid, g)
    save()
    return bj_json(uid, g)


def bj_stand(uid):
    g = bj_get(uid)
    return bj_finish(uid, g)


def settle_blackjack(now):
    changed = False
    for key, g in list(db["bj"].items()):
        if now - g["t"] > BJ_TIMEOUT:
            bj_finish(int(key), g)
            changed = True
    return changed


# ---------------------------------------------------------------------------
# Virtual Earth, the rest of the game: buildings, tax, military, intelligence, wars, sealanes and buyouts
# ---------------------------------------------------------------------------
class Ctx:
    """Who is acting, what they are called, and the one clock every rule in this action uses."""
    def __init__(self, uid, name, other_name=None):
        self.uid, self.name, self.other_name, self.now = uid, name, other_name, time.time()


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def norm_code(code):
    return code.strip().upper() if isinstance(code, str) else ""


def as_text(v):
    return v if isinstance(v, str) else ""


def building(bid):
    return next((b for b in BUILDINGS if b["id"] == bid), None)


def arsenal_item(aid):
    return next((a for a in ARSENAL if a["id"] == aid), None)


def level(n, bid):
    return int(n["lv"].get(bid, 0))


def build_cost(b, lvl):
    return int(round(b["cost"] * (1 + lvl * BUILD_COST_STEP)))


def force_cap(n):
    return int(n["pop"]) // 5


def tend(n, now):
    """Passive GDP growth since the last time anything looked at this nation."""
    hours = max(0.0, now - n["grown_at"]) / 3600
    if hours > 0:
        n["gdp"] *= (1 + GDP_GROWTH_PER_HOUR) ** min(hours, 24 * 30)
        n["grown_at"] = now


def nation_stab(n, fx):
    s = 50 + fx["stab"] + n["stab_adj"] + SCHOOL_STAB * (level(n, "school") + level(n, "hosp"))
    s -= round((n["tax"] - TAX_DEFAULT) * TAX_STAB_PER_POINT)
    return int(clamp(s, 0, 100))


def nation_unrest(n, fx):
    u = fx["unrest"] + max(0, n["tax"] - TAX_DEFAULT) * TAX_UNREST_PER_POINT
    u -= n["relief"] + HOSPITAL_UNREST * level(n, "hosp")
    return int(clamp(round(u), 0, 100))


def eff_divisions(n, fx):
    return int(round(n["div"] * (1 + fx["divisions"])))


def war_power(n, side):
    """side is 'atk' (what it hits with) or 'df' (what it holds with). Troops and hardware count the same for both."""
    fx = policy_fx(n["policy"])
    p = eff_divisions(n, fx) * 12 + n["reserve"] * 6 + n["tanks"] * 6 + n["jets"] * 8 + n["ships"] * 8
    b_key, a_key = ("pw", "atk") if side == "atk" else ("df", "df")
    p += sum(b[b_key] * level(n, b["id"]) for b in BUILDINGS)
    p += sum(a[a_key] for a in ARSENAL if n["ars"].get(a["id"]))
    return p * (1 + fx["combat"]) * (1 + fx["military"])


def find_war(wid):
    wid = as_text(wid)
    return next((w for w in db["wars"] if w["id"] == wid), None)


def war_between(a, b):
    return any({w["a"], w["b"]} == {a, b} for w in db["wars"])


def lane_between(a, b):
    return any({l["a"], l["b"]} == {a, b} for l in db["lanes"]) or \
        any(o["kind"] == "lane" and {o["from_code"], o["to_code"]} == {a, b} for o in db["offers"])


def lane_count(code):
    """Active sealanes plus the proposals this nation has sent that nobody answered yet."""
    return sum(1 for l in db["lanes"] if code in (l["a"], l["b"])) + \
        sum(1 for o in db["offers"] if o["kind"] == "lane" and o["from_code"] == code)


def trades_json(code):
    out = [{"id": l["id"], "to": l["b"] if l["a"] == code else l["a"], "active": True}
           for l in db["lanes"] if code in (l["a"], l["b"])]
    out += [{"id": o["id"], "to": o["to_code"], "active": False}
            for o in db["offers"] if o["kind"] == "lane" and o["from_code"] == code]
    return out


def pub_json(land):
    """What every visitor may see about a claimed nation."""
    n = nation_state(land)
    tend(n, time.time())
    fx = policy_fx(n["policy"])
    return {"gdp": round(n["gdp"], 1), "pop": int(n["pop"]), "div": int(n["div"]),
            "stab": nation_stab(n, fx), "unrest": nation_unrest(n, fx)}


def war_json(w):
    a, b = db["earth"].get(w["a"]), db["earth"].get(w["b"])
    na, nb = (nation_state(a), nation_state(b)) if a and b else (None, None)
    return {"id": w["id"], "a": w["a"], "b": w["b"], "prog": round(w["prog"], 1), "endsAt": int(w["ends"] * 1000),
            "assault": round(war_power(na, "atk") / 10) if na else 0,
            "defense": round(war_power(nb, "df") / 10) if nb else 0}


def offers_json(uid):
    """Offers the member has been sent ('in') and offers they sent that are still waiting ('out')."""
    me = str(uid)
    inc, out = [], []
    for o in db["offers"]:
        target = db["earth"].get(o["code"] if o["kind"] == "buyout" else o["to_code"])
        row = {"id": o["id"], "kind": o["kind"], "from": o["from_name"], "toName": target["name"] if target else "?",
               "expires": int(o["expires"] * 1000)}
        if o["kind"] == "buyout":
            row.update(code=o["code"], price=o["price"])
        else:
            row.update(fromCode=o["from_code"], toCode=o["to_code"], tariff=TRADE_TARIFF)
        if o["to"] == me:
            inc.append(row)
        elif o["from"] == me:
            out.append(row)
    return {"in": inc, "out": out}


def nation_json(code, land):
    """Everything the owner's page needs about their nation. Only ever sent to the owner."""
    n = nation_state(land)
    now = time.time()
    accrue(n, now)
    tend(n, now)
    fx = policy_fx(n["policy"])
    y = land_yield(n)
    return {
        "treasury": int(n["treasury"]), "pending": round(n["pending"], 2), "yieldHr": y,
        "cap": max(y * EARTH_CAP_HOURS, math.ceil(n["pending"])), "capHours": EARTH_CAP_HOURS,
        "fx": fx,
        "stab": nation_stab(n, fx), "unrest": nation_unrest(n, fx),
        "policyReadyAt": {c: int(t * 1000) for c, t in n["ready"].items() if t > now},
        "tax": int(n["tax"]), "gdp": round(n["gdp"], 2), "pop": int(n["pop"]), "div": int(n["div"]),
        "reserve": int(n["reserve"]), "tanks": int(n["tanks"]), "jets": int(n["jets"]), "ships": int(n["ships"]),
        "forceCap": force_cap(n),
        "lv": {k: int(v) for k, v in n["lv"].items() if v},
        "ars": {k: True for k, v in n["ars"].items() if v},
        "buildCost": {b["id"]: build_cost(b, level(n, b["id"])) for b in BUILDINGS},
        "cmd": {s: ({"name": n["cmd"][s]["name"], "awaiting": n["cmd"][s]["accepts_at"] > now}
                    if n["cmd"].get(s) else None) for s in COMMAND_SEATS},
        "ops": [dict(o) for o in n["ops"]], "dossiers": list(n["dossiers"]), "pows": int(n["pows"]),
        "coal": n["coal"], "trades": trades_json(code),
    }


def catalog_json():
    """The things the page needs to draw buttons and labels. The server is the only source of these numbers."""
    return {
        "buildings": BUILDINGS, "arsenal": ARSENAL, "coalitions": COALITIONS,
        "costs": {"fast": COST_FAST, "stim": COST_STIM, "riot": COST_RIOT, "sweep": COST_SWEEP,
                  "dossier": COST_DOSSIER, "op": COST_OPERATIVE, "opMax": OPERATIVE_MAX,
                  "recruit": RECRUIT_COST, "recruitPop": RECRUIT_POP, "taxMax": TAX_MAX_NATION,
                  "taxDefault": TAX_DEFAULT, "tanks": UNIT_COST["tanks"], "jets": UNIT_COST["jets"],
                  "ships": UNIT_COST["ships"], "tariff": TRADE_TARIFF, "laneMax": TRADE_MAX_LANES,
                  "spoils": WAR_SPOILS, "surrender": WAR_SURRENDER_FEE, "warHours": WAR_HOURS,
                  "offerHours": OFFER_HOURS},
    }


def earth_snapshot(uid):
    """Everything about the world that changes: who owns what, wars, and this member's offers."""
    return {"claims": earth_json(uid), "wars": [war_json(w) for w in db["wars"]], "offers": offers_json(uid),
            "serverTime": int(time.time() * 1000)}


# --- Actions on a nation you rule. Each one validates first and writes last, and returns the message to show.
def pay_from_treasury(n, cost):
    cost = int(cost)
    if n["treasury"] < cost:
        raise TradeError(f"Not enough treasury. You need {cost:,} M.")
    n["treasury"] -= cost


def act_fast(ctx, code, land, n, body):
    pay_from_treasury(n, COST_FAST)
    n["gdp"] *= 1.03
    return "Tech fast-tracked. GDP +3%."


def act_stim(ctx, code, land, n, body):
    pay_from_treasury(n, COST_STIM)
    n["gdp"] *= 1.02
    n["pop"] += 4
    return "Growth stimulated. +4 citizens."


def act_riot(ctx, code, land, n, body):
    if nation_unrest(n, policy_fx(n["policy"])) <= 0:
        raise TradeError("No unrest to quell.")
    pay_from_treasury(n, COST_RIOT)
    n["relief"] += 8
    n["stab_adj"] += 2
    return "Unrest eased."


def act_build(ctx, code, land, n, body):
    b = building(as_text(body.get("id")))
    if b is None:
        raise TradeError("That building doesn't exist.")
    lvl = level(n, b["id"])
    pay_from_treasury(n, build_cost(b, lvl))
    n["lv"][b["id"]] = lvl + 1
    return f"{b['name']} is now level {lvl + 1}."


def act_tax(ctx, code, land, n, body):
    pct = whole(body.get("tax"), "Tax", 0, TAX_MAX_NATION)
    if pct == n["tax"]:
        raise TradeError(f"Your tax rate is already {pct}%.")
    n["tax"] = pct                              # the yield earned so far was banked at the old rate before this ran
    return f"National tax is now {pct}%."


def act_appoint(ctx, code, land, n, body):
    seat = as_text(body.get("k"))
    if seat not in COMMAND_SEATS:
        raise TradeError("That seat doesn't exist.")
    taken = {v["name"] for s, v in n["cmd"].items() if v and s != seat}
    name = random.choice([p for p in NPC_NAMES if p not in taken] or NPC_NAMES)
    n["cmd"][seat] = {"name": name, "accepts_at": ctx.now + COMMANDER_ACCEPT_SECONDS}
    return f"Decree sent to {name}."


def act_fire(ctx, code, land, n, body):
    seat = as_text(body.get("k"))
    if seat not in COMMAND_SEATS or not n["cmd"].get(seat):
        raise TradeError("Nobody holds that seat.")
    n["cmd"][seat] = None
    return "Commander dismissed."


def act_recruit_op(ctx, code, land, n, body):
    if len(n["ops"]) >= OPERATIVE_MAX:
        raise TradeError(f"Bureau is full ({OPERATIVE_MAX} operatives).")
    pay_from_treasury(n, COST_OPERATIVE)
    n["ops"].append({"name": f"{random.choice(NPC_NAMES)} {len(n['ops']) + 1}", "spec": random.choice(OPERATIVE_SPECS)})
    return "Operative recruited."


def act_dossier(ctx, code, land, n, body):
    targets = [c for c, l in db["earth"].items()
               if c in EARTH_NATIONS and l["owner"] != str(ctx.uid) and not policy_fx(nation_state(l)["policy"])["spyImmune"]]
    if not targets:
        raise TradeError("No other ruler can be investigated right now. Isolated nations are immune to spies.")
    pay_from_treasury(n, COST_DOSSIER)
    c = random.choice(targets)
    land_t = db["earth"][c]
    t = nation_state(land_t)
    tend(t, ctx.now)
    fx = policy_fx(t["policy"])
    n["dossiers"].append(
        f"{c} {EARTH_NATIONS[c]} (ruler {land_t['name']}): {eff_divisions(t, fx)} divisions and {int(t['reserve'])} in reserve, "
        f"{t['tanks']} tanks, {t['jets']} jets, {t['ships']} ships, {sum(1 for v in t['ars'].values() if v)} arsenal asset(s), "
        f"{t['gdp']:.1f} GDP index, stability {nation_stab(t, fx)}%, treasury {int(t['treasury']):,} M.")
    del n["dossiers"][:-DOSSIER_KEEP]
    return "Dossier decrypted."


def act_sweep(ctx, code, land, n, body):
    pay_from_treasury(n, COST_SWEEP)
    chance = min(0.95, SWEEP_BASE + 0.03 * level(n, "bunker") + (0.15 if n["ars"].get("cyber") else 0))
    if random.random() < chance:
        n["pows"] += 1
        return "Sweep caught an enemy infiltrator."
    return "Sweep found nothing."


def act_recruit(ctx, code, land, n, body):
    k = whole(body.get("n"), "Divisions", 1, 1_000)
    cap = force_cap(n)
    if n["div"] + n["reserve"] + k > cap:
        raise TradeError(f"Force ceiling is {cap} divisions.")
    if n["pop"] < RECRUIT_POP * k:
        raise TradeError("Not enough citizens to recruit that many.")
    pay_from_treasury(n, RECRUIT_COST * k)
    n["reserve"] += k
    n["pop"] -= RECRUIT_POP * k
    return f"{k} division{'s' if k > 1 else ''} added to reserve."


def act_buy(ctx, code, land, n, body):
    kind = as_text(body.get("k"))
    if kind not in UNIT_COST:
        raise TradeError("That unit doesn't exist.")
    pay_from_treasury(n, UNIT_COST[kind])
    n[kind] += 1
    return "Purchased."


def act_procure(ctx, code, land, n, body):
    a = arsenal_item(as_text(body.get("id")))
    if a is None:
        raise TradeError("That asset doesn't exist.")
    if n["ars"].get(a["id"]):
        raise TradeError("You already own that.")
    pay_from_treasury(n, a["cost"])
    n["ars"][a["id"]] = True                    # yield was banked at the old rate before this ran
    return f"{a['name']} procured."


def act_charter(ctx, code, land, n, body):
    i = COALITIONS.index(n["coal"]) if n["coal"] in COALITIONS else 0
    n["coal"] = COALITIONS[(i + 1) % len(COALITIONS)]
    return f"Treaty: {n['coal']}."


# --- Wars. The attacker needs the front to reach 100 before the clock runs out. Each reinforcement sends one
# reserve division: attackers push the front up, defenders push it back, scaled by who is stronger.
def act_declare(ctx, code, land, n, body):
    target = norm_code(body.get("target"))
    tland = db["earth"].get(target)
    if target not in EARTH_NATIONS or tland is None:
        raise TradeError("That nation has no ruler to fight. Unclaimed lands can't be attacked.")
    if tland["owner"] == str(ctx.uid):
        raise TradeError("You can't declare war on your own land.")
    if war_between(code, target):
        raise TradeError("You are already at war with that nation.")
    db["wars"].append({"id": secrets.token_hex(4), "a": code, "b": target, "prog": 0.0,
                       "started": ctx.now, "ends": ctx.now + WAR_HOURS * 3600})
    return f"War declared on {EARTH_NATIONS[target]}."


def my_war(code, body):
    w = find_war(body.get("id"))
    if w is None or code not in (w["a"], w["b"]):
        raise TradeError("That war isn't yours to fight.")
    return w


def act_reinforce(ctx, code, land, n, body):
    w = my_war(code, body)
    if n["reserve"] < 1:
        raise TradeError("No reserve divisions to send.")
    na, nb = nation_state(db["earth"][w["a"]]), nation_state(db["earth"][w["b"]])
    ratio = max(war_power(na, "atk"), 1.0) / max(war_power(nb, "df"), 1.0)
    n["reserve"] -= 1
    if code == w["a"]:
        w["prog"] = min(100.0, w["prog"] + WAR_STEP * clamp(ratio, 0.25, 3.0))
        if w["prog"] < 100:
            return "Front reinforced."
        spoils = int(min(WAR_SPOILS, nb["treasury"]))
        nb["treasury"] -= spoils
        na["treasury"] += spoils
        db["wars"].remove(w)
        if spoils:
            return f"Victory over {EARTH_NATIONS[w['b']]}. {spoils:,} M in spoils."
        return f"Victory over {EARTH_NATIONS[w['b']]}. Their treasury was empty, so there are no spoils."
    w["prog"] = max(0.0, w["prog"] - WAR_STEP * clamp(1 / ratio, 0.25, 3.0))
    return "Front held. The enemy advance was pushed back."


def act_concede(ctx, code, land, n, body):
    w = my_war(code, body)
    other = w["b"] if code == w["a"] else w["a"]
    fee = int(min(WAR_SURRENDER_FEE, n["treasury"]))
    n["treasury"] -= fee
    nation_state(db["earth"][other])["treasury"] += fee
    n["stab_adj"] -= 6
    db["wars"].remove(w)
    return f"War ended. You paid {fee:,} M in indemnities to {EARTH_NATIONS[other]}."


# --- Sealanes: one nation proposes, the other has OFFER_HOURS to ratify. Active lanes pay both sides daily.
def act_sealane(ctx, code, land, n, body):
    target = norm_code(body.get("target"))
    tland = db["earth"].get(target)
    if target not in EARTH_NATIONS or tland is None:
        raise TradeError("That nation has no ruler to trade with.")
    if tland["owner"] == str(ctx.uid):
        raise TradeError("You can't open a lane to your own land.")
    if lane_between(code, target):
        raise TradeError("You already have a lane or an open proposal with that nation.")
    if lane_count(code) >= TRADE_MAX_LANES:
        raise TradeError(f"A nation can have at most {TRADE_MAX_LANES} sealanes or open proposals.")
    db["offers"].append({"id": secrets.token_hex(4), "kind": "lane", "from": str(ctx.uid), "from_name": ctx.name,
                         "from_code": code, "to": tland["owner"], "to_code": target,
                         "created": ctx.now, "expires": ctx.now + OFFER_HOURS * 3600})
    return f"Proposal sent to {EARTH_NATIONS[target]}."


def act_term(ctx, code, land, n, body):
    ident = as_text(body.get("id"))
    lane = next((l for l in db["lanes"] if l["id"] == ident and code in (l["a"], l["b"])), None)
    if lane:
        db["lanes"].remove(lane)
        return "Trade lane closed."
    offer = next((o for o in db["offers"] if o["id"] == ident and o["kind"] == "lane" and o["from_code"] == code), None)
    if offer:
        db["offers"].remove(offer)
        return "Proposal withdrawn."
    raise TradeError("That trade lane doesn't exist.")


LAND_ACTIONS = {
    "fast": act_fast, "stim": act_stim, "riot": act_riot, "build": act_build, "tax": act_tax,
    "appoint": act_appoint, "fire": act_fire, "recruit-op": act_recruit_op, "dossier": act_dossier,
    "sweep": act_sweep, "recruit": act_recruit, "buy": act_buy, "procure": act_procure, "charter": act_charter,
    "declare": act_declare, "reinforce": act_reinforce, "concede": act_concede,
    "sealane": act_sealane, "term": act_term,
}


# --- Offers: buyouts and sealane proposals. A buyer's money is held (taken from their wallet) until the
# owner answers, the offer expires, or the buyer takes it back, so an offer can never be a bluff.
def find_offer(oid):
    oid = as_text(oid)
    return next((o for o in db["offers"] if o["id"] == oid), None)


def refund_offer(o):
    if o["kind"] == "buyout":
        get_user(o["from"])["medals"] += o["price"]


def free_buyout(ctx, body):
    code = norm_code(body.get("code"))
    land = db["earth"].get(code)
    if code not in EARTH_NATIONS or land is None:
        raise TradeError("That land has no ruler to buy from. Claim it for free instead.")
    if land["owner"] == str(ctx.uid):
        raise TradeError("That land is already yours.")
    price = whole(body.get("price"), "Offer", 1, 1_000_000_000)
    if any(o["kind"] == "buyout" and o["from"] == str(ctx.uid) and o["code"] == code for o in db["offers"]):
        raise TradeError("You already have an offer on that land. Take it back first to change the price.")
    me = get_user(ctx.uid)
    if price > me["medals"]:
        raise TradeError(f"You only have {me['medals']:,} M in your wallet.")
    me["medals"] -= price
    db["offers"].append({"id": secrets.token_hex(4), "kind": "buyout", "from": str(ctx.uid), "from_name": ctx.name,
                         "to": land["owner"], "code": code, "price": price,
                         "created": ctx.now, "expires": ctx.now + OFFER_HOURS * 3600})
    return f"Offer of {price:,} M sent to {land['name']}. They have {OFFER_HOURS}h to reply. The medals are held until then."


def tidy_world():
    """Run whenever land changes hands: drops every offer, lane and war that no longer makes sense."""
    earth = db["earth"]
    for o in list(db["offers"]):
        if o["kind"] == "buyout":
            land = earth.get(o["code"])
            if land is None or land["owner"] != o["to"]:
                refund_offer(o)
                db["offers"].remove(o)
        else:
            a, b = earth.get(o["from_code"]), earth.get(o["to_code"])
            if not a or not b or a["owner"] != o["from"] or b["owner"] != o["to"]:
                db["offers"].remove(o)
    for l in list(db["lanes"]):
        a, b = earth.get(l["a"]), earth.get(l["b"])
        if not a or not b or a["owner"] == b["owner"]:
            db["lanes"].remove(l)
    for w in list(db["wars"]):
        a, b = earth.get(w["a"]), earth.get(w["b"])
        if not a or not b or a["owner"] == b["owner"]:
            db["wars"].remove(w)


def free_accept(ctx, body):
    o = find_offer(body.get("id"))
    if o is None or o["to"] != str(ctx.uid):
        raise TradeError("That offer isn't addressed to you.")
    if o["expires"] <= ctx.now:
        raise TradeError("That offer has expired.")
    earth = db["earth"]
    if o["kind"] == "buyout":
        land = earth.get(o["code"])
        if land is None or land["owner"] != str(ctx.uid):
            raise TradeError("You no longer rule that land.")
        get_user(ctx.uid)["medals"] += o["price"]
        db["offers"].remove(o)
        land["owner"] = o["from"]
        land["name"] = ctx.other_name or o["from_name"]
        tidy_world()
        return f"Sold {EARTH_NATIONS[o['code']]} for {o['price']:,} M."
    a, b = earth.get(o["from_code"]), earth.get(o["to_code"])
    if not a or not b or a["owner"] != o["from"] or b["owner"] != str(ctx.uid):
        raise TradeError("That proposal is no longer valid.")
    if lane_count(o["to_code"]) >= TRADE_MAX_LANES:
        raise TradeError(f"A nation can have at most {TRADE_MAX_LANES} sealanes or open proposals.")
    db["offers"].remove(o)
    db["lanes"].append({"id": secrets.token_hex(4), "a": o["from_code"], "b": o["to_code"],
                        "since": ctx.now, "last": ctx.now})
    return f"Sealane to {EARTH_NATIONS[o['from_code']]} ratified. {TRADE_TARIFF:,} M a day starts flowing to both of you."


def free_decline(ctx, body):
    o = find_offer(body.get("id"))
    if o is None or o["to"] != str(ctx.uid):
        raise TradeError("That offer isn't addressed to you.")
    refund_offer(o)
    db["offers"].remove(o)
    return "Offer declined."


def free_cancel(ctx, body):
    o = find_offer(body.get("id"))
    if o is None or o["from"] != str(ctx.uid):
        raise TradeError("That isn't your offer.")
    refund_offer(o)
    db["offers"].remove(o)
    return "Offer taken back." if o["kind"] == "buyout" else "Proposal withdrawn."


FREE_ACTIONS = {"buyout": free_buyout, "offer_accept": free_accept, "offer_decline": free_decline,
                "offer_cancel": free_cancel}


def run_earth_action(uid, name, body, other_name=None):
    """One door for every Virtual Earth action. Returns the message to show."""
    world_tick()                                # expire offers, pay lanes, end stale wars before anything is judged
    ctx = Ctx(uid, name, other_name)
    action = as_text(body.get("action"))
    free = FREE_ACTIONS.get(action)
    if free:
        msg = free(ctx, body)
    else:
        fn = LAND_ACTIONS.get(action)
        if fn is None:
            raise TradeError("That action doesn't exist.")
        code, land = own_land(uid, body.get("code"))
        n = nation_state(land)
        accrue(n, ctx.now)                      # bank what the land earned at its current rate before anything changes it
        tend(n, ctx.now)
        msg = fn(ctx, code, land, n, body)
    save()
    return msg


# --- Things that happen with time. Called every minute by the watcher, and before an action is run.
def expire_offers(now):
    changed = False
    for o in list(db["offers"]):
        if o["expires"] <= now:
            refund_offer(o)
            db["offers"].remove(o)
            changed = True
    return changed


def settle_lanes(now):
    """Pays each active sealane's daily tariff to both nations (up to a week of back pay after downtime)."""
    changed = False
    for l in list(db["lanes"]):
        a, b = db["earth"].get(l["a"]), db["earth"].get(l["b"])
        if not a or not b:
            db["lanes"].remove(l)
            changed = True
            continue
        days = int((now - l["last"]) // DAY)
        if days > 0:
            for land in (a, b):
                nation_state(land)["treasury"] += TRADE_TARIFF * min(days, 7)
            l["last"] += days * DAY
            changed = True
    return changed


def settle_wars(now):
    changed = False
    for w in list(db["wars"]):
        if w["ends"] <= now:                    # nobody won in time: a stalemate, nothing changes hands
            db["wars"].remove(w)
            changed = True
    return changed


def world_tick(now=None):
    now = now or time.time()
    changed = expire_offers(now)
    changed = settle_lanes(now) or changed
    changed = settle_wars(now) or changed
    changed = settle_blackjack(now) or changed
    if changed:
        save()
    return changed


# ---------------------------------------------------------------------------
# Mayor and elections for the website (the same rules as /election and /mayor in Discord)
# ---------------------------------------------------------------------------
def election_open():
    el = db["election"]
    return el if el and time.time() < el["ends"] else None


def web_register(uid):
    el = election_open()
    if not el:
        raise TradeError("There's no open election right now.")
    key = str(uid)
    if key in el["candidates"]:
        raise TradeError("You're already on the ballot.")
    if len(el["candidates"]) >= MAX_CANDIDATES:
        raise TradeError(f"The ballot is full ({MAX_CANDIDATES} candidates).")
    me = get_user(uid)
    if me["medals"] < CANDIDATE_FEE:
        raise TradeError(f"Running costs {CANDIDATE_FEE:,} M. You have {me['medals']:,} M.")
    me["medals"] -= CANDIDATE_FEE
    el["candidates"][key] = {"registered": time.time()}
    save()
    return {"candidates": len(el["candidates"]), "wallet": me["medals"]}


def web_vote(uid, candidate, created, joined):
    """created/joined are the voter's Discord account and server-join times, kept for /election audit."""
    el = election_open()
    if not el:
        raise TradeError("There's no open election right now.")
    cid = as_text(candidate)
    if cid not in el["candidates"]:
        raise TradeError("That person isn't a registered candidate.")
    if uid in el["banned"]:
        raise TradeError("Your earlier ballot was removed by staff, so you can't vote again.")
    voter = str(uid)
    if voter in el["votes"]:
        raise TradeError("You've already cast your ballot.")
    el["votes"][voter] = {"cand": int(cid), "t": time.time(), "acct": created, "joined": joined}
    save()
    return {"voted": cid}


# ---------------------------------------------------------------------------
# Bot
# ---------------------------------------------------------------------------
intents = discord.Intents.default()
# Only needed for /election broadcast_dm. Turn on "Server Members Intent" in the
# Developer Portal (Bot tab) and set MEMBERS_INTENT=1 in your .env to enable it.
if os.environ.get("MEMBERS_INTENT") == "1":
    intents.members = True


class WhyBot(discord.Client):
    def __init__(self):
        super().__init__(intents=intents)
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self):
        self.tree.copy_global_to(guild=GUILD)
        await self.tree.sync(guild=GUILD)
        watcher.start()
        stock_ticker.start()
        dividend_watcher.start()
        await start_web()


bot = WhyBot()
bg_tasks = set()


@tasks.loop(minutes=1)
async def watcher():
    """Auto-ends elections and Mayor terms when their time is up. Also runs the Virtual Earth clock."""
    try:
        world_tick()
    except Exception as e:
        print("world_tick error:", e)
    try:
        guild = bot.get_guild(GUILD.id)
        if guild is None:
            return
        channel = guild.get_channel(db.get("announce_channel") or 0)
        el = db["election"]
        if el and time.time() >= el["ends"]:
            embed = await conclude_election(guild)
            if channel:
                await channel.send(embed=embed)
        mayor_state = db["mayor"]
        if mayor_state and time.time() >= mayor_state["term_end"]:
            await clear_mayor(guild)
            if channel:
                await channel.send(embed=make_embed(
                    "🏛️ The Mayor's term has ended",
                    "The office is vacant. Time for a new election!",
                    "info",
                ))
    except Exception as e:  # keep the loop alive
        print("watcher error:", e)


@watcher.before_loop
async def before_watcher():
    await bot.wait_until_ready()


@tasks.loop(seconds=STOCK_TICK_SECONDS)
async def stock_ticker():
    try:
        tick_prices()
        save()
    except Exception as e:  # keep the loop alive
        print("stock_ticker error:", e)


@tasks.loop(minutes=5)
async def dividend_watcher():
    """Checks every few minutes; pay_dividends only pays once per whole hour."""
    try:
        pay_dividends()
    except Exception as e:
        print("dividend_watcher error:", e)


# ---------------------------------------------------------------------------
# Basic economy: /balance /daily /weekly /crime /globallb /guide
# ---------------------------------------------------------------------------
@bot.tree.command(name="balance", description="Check your medals")
async def balance(interaction: discord.Interaction):
    me = get_user(interaction.user.id)
    fields = [("👛 Wallet", f"**{me['medals']:,}** M", True)]
    if me["bank"]:
        b = me["bank"]
        refresh_bank(b)
        save()
        fields.append((
            "🏦 Vault",
            f"**{b['vault']:,}** M\n`{meter(b['vault'], vault_cap(b))}` / {vault_cap(b):,}",
            True,
        ))
        if b["loan"]:
            fields.append(("💳 Loan owed", f"**{b['loan']:,}** M\ndue {ts(b['due'])}", True))
    await say(
        interaction, f"💰 {interaction.user.display_name}'s balance", None, "gold",
        fields=fields, footer=f"Net worth: {total_medals(me):,} M",
    )


@bot.tree.command(name="daily", description="Claim your daily Medals and build a streak")
async def daily(interaction: discord.Interaction):
    me = get_user(interaction.user.id)
    now = time.time()
    if now < me["last_daily"] + DAY:
        await cooldown(interaction, "⏳ Already claimed today", me["last_daily"] + DAY)
        return
    me["streak"] = me["streak"] + 1 if now - me["last_daily"] < 2 * DAY else 1
    me["last_daily"] = now
    me["medals"] += DAILY_REWARD
    save()
    weekly_ready = now >= me["last_weekly"] + WEEK
    footer = "📦 Your /weekly is ready too!" if weekly_ready else "Come back tomorrow to keep the streak alive!"
    await say(
        interaction, "🎁 Daily reward claimed!", f"*{random.choice(DAILY_LINES)}*", "ok",
        fields=[
            ("💰 Reward", f"+**{DAILY_REWARD:,}** M", True),
            ("🔥 Streak", f"`{streak_bar(me['streak'])}`\nDay **{me['streak']}**", True),
            ("👛 Wallet", f"**{me['medals']:,}** M", True),
        ],
        footer=footer,
    )


@bot.tree.command(name="weekly", description="Claim your weekly care package and build a weekly streak")
async def weekly(interaction: discord.Interaction):
    me = get_user(interaction.user.id)
    now = time.time()
    if now < me["last_weekly"] + WEEK:
        await cooldown(interaction, "⏳ Your weekly package isn't ready", me["last_weekly"] + WEEK)
        return
    # claiming within 2 weeks of the last one keeps the streak
    me["weekly_streak"] = me["weekly_streak"] + 1 if now - me["last_weekly"] < 2 * WEEK else 1
    bonus_weeks = min(me["weekly_streak"] - 1, WEEKLY_MAX_BONUS_WEEKS)
    reward = WEEKLY_BASE + bonus_weeks * WEEKLY_STREAK_BONUS
    me["last_weekly"] = now
    me["medals"] += reward
    save()
    maxed = bonus_weeks >= WEEKLY_MAX_BONUS_WEEKS
    await say(
        interaction, "📦 Weekly care package opened!", f"*{random.choice(WEEKLY_LINES)}*", "gold",
        fields=[
            ("💰 Reward", f"+**{reward:,}** M" + (f"\n(+{bonus_weeks * WEEKLY_STREAK_BONUS:,} streak bonus)" if bonus_weeks else ""), True),
            ("🔥 Weekly streak", f"**{me['weekly_streak']}** week(s)" + ("\n⭐ max bonus!" if maxed else ""), True),
            ("👛 Wallet", f"**{me['medals']:,}** M", True),
        ],
        footer=f"Claim every week to grow the bonus (up to +{WEEKLY_MAX_BONUS_WEEKS * WEEKLY_STREAK_BONUS:,} M).",
    )


@bot.tree.command(name="crime", description="Commit a high-risk criminal operation (2h cooldown)")
async def crime(interaction: discord.Interaction):
    me = get_user(interaction.user.id)
    now = time.time()
    if now < me["last_crime"] + CRIME_COOLDOWN:
        await cooldown(interaction, "🚔 Lay low for a while", me["last_crime"] + CRIME_COOLDOWN)
        return
    me["last_crime"] = now
    if random.random() < 0.45:
        gain = random.randint(2_000, 10_000)
        me["medals"] += gain
        final = make_embed(
            "💎 Crime pays!", f"{random.choice(CRIME_WIN)}.", "ok",
            fields=[("💰 Loot", f"+**{gain:,}** M", True), ("👛 Wallet", f"**{me['medals']:,}** M", True)],
            footer="Next job available in 2 hours.",
        )
    else:
        fine = min(me["medals"], random.randint(1_000, 5_000))
        me["medals"] -= fine
        final = make_embed(
            "🚨 Busted!", f"{random.choice(CRIME_LOSE)}.", "bad",
            fields=[("💸 Fined", f"-**{fine:,}** M", True), ("👛 Wallet", f"**{me['medals']:,}** M", True)],
            footer="Next job available in 2 hours.",
        )
    save()
    await say(interaction, "🕵️ Casing the joint...", "*You pull your hood up and slip into the night...*", "warn")
    await asyncio.sleep(1.5)
    await interaction.edit_original_response(embed=final)


@bot.tree.command(name="work", description=f"Work a shift for {WORK_MIN}-{WORK_MAX} medals ({WORK_COOLDOWN // 3600}h cooldown)")
async def work(interaction: discord.Interaction):
    me = get_user(interaction.user.id)
    now = time.time()
    if now < me["last_work"] + WORK_COOLDOWN:
        await cooldown(interaction, "😮\u200d💨 You need a break", me["last_work"] + WORK_COOLDOWN)
        return
    pay = random.randint(WORK_MIN, WORK_MAX)
    me["last_work"] = now
    me["medals"] += pay
    save()
    await say(
        interaction, "🔨 Shift complete!", f"*{random.choice(WORK_LINES)}*", "ok",
        fields=[("💰 Pay", f"+**{pay:,}** M", True), ("👛 Wallet", f"**{me['medals']:,}** M", True)],
        footer=f"Next shift available in {WORK_COOLDOWN // 3600} hour(s).",
    )


class TriviaView(discord.ui.View):
    def __init__(self, interaction, question, options, correct, reward):
        super().__init__(timeout=TRIVIA_TIME)
        self.interaction = interaction
        self.user_id = interaction.user.id
        self.question = question
        self.options = options
        self.correct = correct
        self.reward = reward
        self.finished = False
        for i, text in enumerate(options):
            button = discord.ui.Button(label=f"{'ABCD'[i]}. {text}", style=discord.ButtonStyle.primary)
            button.callback = self.make_callback(i)
            self.add_item(button)

    def question_embed(self):
        return make_embed(
            "🧠 Trivia time!", f"**{self.question}**", "info",
            footer=f"Answer within {TRIVIA_TIME} seconds. Correct answers pay {TRIVIA_MIN}-{TRIVIA_MAX} M.",
        )

    def result_embed(self, title, kind, note=None):
        me = get_user(self.user_id)
        fields = [("👛 Wallet", f"**{me['medals']:,}** M", True)]
        if kind == "ok":
            fields.insert(0, ("💰 Reward", f"+**{self.reward:,}** M", True))
        desc = f"**{self.question}**\nThe answer was **{self.options[self.correct]}**."
        if note:
            desc += f"\n*{note}*"
        return make_embed(title, desc, kind, fields=fields)

    def make_callback(self, index):
        async def callback(interaction: discord.Interaction):
            if self.finished:
                return
            self.finished = True
            self.stop()
            if index == self.correct:
                get_user(self.user_id)["medals"] += self.reward
                save()
                embed = self.result_embed("✅ Correct!", "ok")
            else:
                embed = self.result_embed("❌ Not quite", "bad")
            await interaction.response.edit_message(embed=embed, view=None)
        return callback

    async def interaction_check(self, interaction):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This isn't your question.", ephemeral=True)
            return False
        return True

    async def on_timeout(self):
        if self.finished:
            return
        self.finished = True
        try:
            await self.interaction.edit_original_response(
                embed=self.result_embed("⌛ Time's up!", "warn"), view=None
            )
        except discord.HTTPException:
            pass


@bot.tree.command(name="trivia", description=f"Answer a general knowledge question for {TRIVIA_MIN}-{TRIVIA_MAX} medals")
async def trivia(interaction: discord.Interaction):
    me = get_user(interaction.user.id)
    now = time.time()
    if now < me["last_trivia"] + TRIVIA_COOLDOWN:
        await cooldown(interaction, "🧠 Give your brain a rest", me["last_trivia"] + TRIVIA_COOLDOWN)
        return
    me["last_trivia"] = now  # counts even if you walk away, so you can't re-roll questions
    save()
    question, answer, wrong = random.choice(TRIVIA)
    options = [answer] + wrong
    random.shuffle(options)
    view = TriviaView(
        interaction, question, options, options.index(answer),
        random.randint(TRIVIA_MIN, TRIVIA_MAX),
    )
    await interaction.response.send_message(embed=view.question_embed(), view=view)


@bot.tree.command(name="transfer", description="Send medals to another member (the Mayor's market tax applies)")
@app_commands.describe(member="Who gets the medals", amount="Medals to send (the tax is taken out of this)")
async def transfer(interaction: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1]):
    if member.bot or member.id == interaction.user.id:
        await deny(interaction, "Pick another member.")
        return
    me = get_user(interaction.user.id)
    if amount > me["medals"]:
        await deny(interaction, f"You only have **{me['medals']:,}** M in your wallet.")
        return
    rate = db["tax"]
    tax = -(-amount * rate // 100)  # rounded up, so small transfers can't dodge the tax
    received = amount - tax
    if received < 1:
        await deny(interaction, f"**{amount:,}** M is too small to send after the {rate}% tax.")
        return
    me["medals"] -= amount
    get_user(member.id)["medals"] += received
    bank_collect("transfer", tax)
    save()
    where = "to the Market Bank" if TAX_TO_MARKET_BANK else "burned"
    await say(
        interaction, "💸 Transfer complete",
        f"{interaction.user.mention} sent medals to {member.mention}.", "ok",
        content=member.mention,
        fields=[
            ("📤 Sent", f"**{amount:,}** M", True),
            (f"🏛️ Market tax ({rate}%)", f"-**{tax:,}** M", True),
            ("📥 Received", f"**{received:,}** M", True),
        ],
        footer=f"Tax goes {where}. Your wallet: {me['medals']:,} M",
    )


@bot.tree.command(name="givemedals", description="[Owner/Administrator] Give medals to yourself or another member")
@app_commands.describe(amount="Medals to give", member="Who gets them (defaults to you)")
async def givemedals(
    interaction: discord.Interaction,
    amount: app_commands.Range[int, 1],
    member: Optional[discord.Member] = None,
):
    roles = {r.name for r in getattr(interaction.user, "roles", [])}
    allowed = is_owner(interaction) or any(name in roles for name in STAFF_ROLE)
    if not allowed:
        await deny(interaction, "Only the Owner and Administrator roles can use this.")
        return
    target = member or interaction.user
    if target.bot:
        await deny(interaction, "Bots don't need medals.")
        return
    u = get_user(target.id)
    u["medals"] += amount
    save()
    await say(
        interaction, "🎁 Medals granted",
        f"{interaction.user.mention} gave medals to {target.mention}.", "gold",
        fields=[("💰 Amount", f"+**{amount:,}** M", True), ("👛 Wallet", f"**{u['medals']:,}** M", True)],
    )


@bot.tree.command(name="globallb", description="Top medal earners across all connected clans and servers")
async def globallb(interaction: discord.Interaction):
    rows = sorted(
        ((uid, total_medals(u)) for uid, u in db["users"].items()),
        key=lambda r: r[1], reverse=True,
    )[:10]
    rows = [r for r in rows if r[1] > 0]
    if not rows:
        await deny(interaction, "Nobody has any medals yet. Be the first with `/daily`!")
        return
    badges = ["🥇", "🥈", "🥉"]
    lines = [
        f"{badges[i] if i < 3 else f'**{i + 1}.**'} <@{uid}>: **{amount:,}** M"
        for i, (uid, amount) in enumerate(rows)
    ]
    await say(interaction, "🏆 Global leaderboard", "\n".join(lines), "gold",
              footer="Wallet + vault combined")


# ---------------------------------------------------------------------------
# Stocks: /stocks /buy /sell /portfolio
# ---------------------------------------------------------------------------
async def ticker_autocomplete(interaction: discord.Interaction, current: str):
    q = current.strip().upper()
    return [
        app_commands.Choice(name=f"{t} - {s['name']}"[:100], value=t)
        for t, s in db["stocks"].items() if q in t or q in s["name"].upper()
    ][:25]


def arrow(pct):
    return f"{'🟢' if pct >= 0 else '🔴'} {pct:+.2f}%"


@bot.tree.command(name="stocks", description="See the stock market")
async def stocks_cmd(interaction: discord.Interaction):
    lines = [
        f"**{t}** · {s['name']}\n{s['price']:,.0f} M · {arrow(stock_change(s))} · "
        f"{s['avail']:,}/{STOCK_SUPPLY:,} left"
        for t, s in db["stocks"].items()
    ]
    await say(
        interaction, "📈 Why Stock Market", "\n\n".join(lines) or "Nothing is listed.", "gold",
        footer=f"Trade with /buy and /sell · fee {fee_rate()}% · max {STOCK_MAX_PER_MEMBER} shares each · "
               f"{STOCK_DIVIDEND * 100:g}% dividend every hour",
    )


@bot.tree.command(name="buy", description="Buy shares of a stock")
@app_commands.describe(ticker="Which stock", shares=f"How many shares (up to {STOCK_MAX_PER_MEMBER})")
@app_commands.autocomplete(ticker=ticker_autocomplete)
async def buy_cmd(interaction: discord.Interaction, ticker: str,
                  shares: app_commands.Range[int, 1, STOCK_MAX_PER_MEMBER]):
    try:
        r = buy_shares(interaction.user.id, ticker, shares)
    except TradeError as e:
        await deny(interaction, str(e))
        return
    await say(
        interaction, f"✅ Bought {r['qty']} {r['ticker']}",
        f"{interaction.user.mention} bought **{r['qty']}** share(s) at **{r['price']:,.0f}** M.", "ok",
        fields=[
            ("🧾 Shares", f"{r['base']:,} M", True),
            (f"🏛️ Fee ({r['rate']}%)", f"{r['fee']:,} M", True),
            ("💸 Total", f"**{r['total']:,}** M", True),
        ],
        footer=f"You hold {r['held']} {r['ticker']} · wallet {r['wallet']:,} M · price now {r['new_price']:,.0f} M",
    )


@bot.tree.command(name="sell", description="Sell shares of a stock")
@app_commands.describe(ticker="Which stock", shares=f"How many shares (up to {STOCK_MAX_PER_MEMBER})")
@app_commands.autocomplete(ticker=ticker_autocomplete)
async def sell_cmd(interaction: discord.Interaction, ticker: str,
                   shares: app_commands.Range[int, 1, STOCK_MAX_PER_MEMBER]):
    try:
        r = sell_shares(interaction.user.id, ticker, shares)
    except TradeError as e:
        await deny(interaction, str(e))
        return
    await say(
        interaction, f"💰 Sold {r['qty']} {r['ticker']}",
        f"{interaction.user.mention} sold **{r['qty']}** share(s) at **{r['price']:,.0f}** M.", "ok",
        fields=[
            ("🧾 Shares", f"{r['base']:,} M", True),
            (f"🏛️ Fee ({r['rate']}%)", f"-{r['fee']:,} M", True),
            ("📥 Received", f"**{r['total']:,}** M", True),
        ],
        footer=f"You hold {r['held']} {r['ticker']} · wallet {r['wallet']:,} M · price now {r['new_price']:,.0f} M",
    )


@bot.tree.command(name="portfolio", description="Your stock holdings")
async def portfolio(interaction: discord.Interaction):
    me = get_user(interaction.user.id)
    rows, worth, cost = [], 0, 0
    for t, h in me["holdings"].items():
        s = db["stocks"].get(t)
        if not s:
            continue
        value = h["q"] * s["price"]
        pl = value - h["q"] * h["avg"]
        worth += value
        cost += h["q"] * h["avg"]
        rows.append(f"**{t}** · {h['q']} sh · avg {h['avg']:,.0f} M · now {s['price']:,.0f} M\n"
                    f"worth {value:,.0f} M · {'🟢' if pl >= 0 else '🔴'} {pl:+,.0f} M")
    if not rows:
        await deny(interaction, "You don't own any shares yet. See `/stocks`, then `/buy`.")
        return
    hourly = sum(math.floor(h["q"] * db["stocks"][t]["price"] * STOCK_DIVIDEND)
                 for t, h in me["holdings"].items() if t in db["stocks"])
    await say(
        interaction, f"💼 {interaction.user.display_name}'s portfolio", "\n\n".join(rows), "gold",
        fields=[("📊 Worth", f"**{worth:,.0f}** M", True),
                ("📈 Profit/loss", f"{worth - cost:+,.0f} M", True),
                ("🪙 Dividends", f"~{hourly:,} M / hour", True)],
        footer="Share value isn't counted on /globallb",
    )


@bot.tree.command(name="guide", description="How the Why bot works")
async def guide(interaction: discord.Interaction):
    await say(
        interaction, "📖 Why bot guide", "Everything you can do with medals (M).", "info",
        fields=[
            ("🎁 Earning",
             "`/daily` streak reward\n`/weekly` bigger reward that grows each week\n"
             f"`/work` a shift for {WORK_MIN}-{WORK_MAX} M ({WORK_COOLDOWN // 3600}h cooldown)\n"
             f"`/trivia` answer a question for {TRIVIA_MIN}-{TRIVIA_MAX} M ({TRIVIA_COOLDOWN // 60}m cooldown)\n"
             "`/crime` risky job (2h cooldown)\n`/mayor salary` the Mayor's paycheck", False),
            ("💸 Market",
             f"`/transfer` send medals to a member. The Mayor's tax applies (now **{db['tax']}%**)\n"
             f"`/mayor tax` the Mayor sets the tax, 0-{MAX_TAX}%", False),
            ("🏦 Bank",
             f"`/bank create` opens an account ({BANK_FEE} M) with a vault password\n"
             "`/bank deposit` · `/bank withdraw` move medals in and out\n"
             "`/bank upgrade` raise your vault cap (up to 1M)\n"
             "`/bank loan` · `/bank repay` borrow and pay back (10% fee, due in 2 days)\n"
             "`/bank rob` guess a password to steal 25% of a vault\n"
             "Vault medals earn **1% daily interest**.", False),
            ("📈 Stocks",
             "`/stocks` live prices · `/buy` · `/sell` · `/portfolio`\n"
             f"Fee {fee_rate()}% per trade (the Mayor's tax, at least {STOCK_MIN_FEE}%), "
             f"{STOCK_MAX_PER_MEMBER} shares max per stock, {STOCK_DIVIDEND * 100:g}% dividend every hour.", False),
            ("🎲 Gambling",
             "`/coinflip` wins pay 1.9x\n`/blackjack` beat the dealer, blackjack pays 3:2\n"
             f"`/dice` two dice each, beat the house to win 2x, ties go to the house (min {DICE_MIN_BET:,} M)", False),
            ("🌍 Virtual Earth",
             "`/harvest` collect your land's yield into your treasury\n"
             "`/treasury deposit` · `/treasury withdraw` move medals in and out\n"
             "`/policy` change your nation's policies (each category once an hour)\n"
             "Claim your land on the website's Virtual Earth map.", False),
            ("🏦 Market Bank",
             "Market tax and trading fees are paid here. `/marketbank balance` · `withdraw` · `deposit` "
             "for the Mayor, Owner and Administrators.", False),
            ("🗳️ Elections",
             f"`/election status` see the race\n`/election register` costs {CANDIDATE_FEE:,} M "
             f"(max {MAX_CANDIDATES})\n`/election vote` cast one ballot\nThe Mayor serves {TERM_DAYS} days.", False),
            ("🏆 Rankings", "`/globallb` top medal holders", False),
        ],
        footer="Tip: use a throwaway vault password, never a real one.",
    )


# ---------------------------------------------------------------------------
# Gambling: /coinflip /blackjack
# ---------------------------------------------------------------------------
@bot.tree.command(name="coinflip", description="Gamble your Medals against the bot")
@app_commands.describe(bet="Medals to bet", side="Heads or tails")
@app_commands.choices(
    side=[
        app_commands.Choice(name="Heads", value="heads"),
        app_commands.Choice(name="Tails", value="tails"),
    ]
)
async def coinflip(
    interaction: discord.Interaction,
    bet: app_commands.Range[int, 1],
    side: app_commands.Choice[str],
):
    me = get_user(interaction.user.id)
    if bet > me["medals"]:
        await deny(interaction, f"You only have **{me['medals']:,}** M in your wallet.")
        return
    result = random.choice(["heads", "tails"])
    if result == side.value:
        win = int(bet * COINFLIP_PAYOUT)  # total payout is 1.9x the bet
        me["medals"] += win
        record_gamble(me, win)
        final = make_embed(
            f"🪙 It's {result}! You win!", f"You called **{side.value}** and the coin agreed.", "ok",
            fields=[("💰 Won", f"+**{win:,}** M", True), ("👛 Wallet", f"**{me['medals']:,}** M", True)],
        )
    else:
        me["medals"] -= bet
        record_gamble(me, -bet)
        final = make_embed(
            f"🪙 It's {result}... ouch.", f"You called **{side.value}**. The coin had other plans.", "bad",
            fields=[("💸 Lost", f"-**{bet:,}** M", True), ("👛 Wallet", f"**{me['medals']:,}** M", True)],
        )
    save()
    await say(interaction, "🪙 Flipping...", f"*{interaction.user.display_name} bets **{bet:,}** M on {side.value}. The coin spins...*", "warn")
    await asyncio.sleep(1.3)
    await interaction.edit_original_response(embed=final)


RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]
SUITS = ["♠", "♥", "♦", "♣"]


def hand_value(hand):
    total, aces = 0, 0
    for rank, _ in hand:
        if rank == "A":
            total += 11
            aces += 1
        elif rank in ("J", "Q", "K"):
            total += 10
        else:
            total += int(rank)
    while total > 21 and aces:
        total -= 10
        aces -= 1
    return total


def show_hand(hand):
    return " ".join(f"`{r}{s}`" for r, s in hand)


class BlackjackView(discord.ui.View):
    def __init__(self, interaction, bet):
        super().__init__(timeout=90)
        self.interaction = interaction
        self.user_id = interaction.user.id
        self.bet = bet
        self.finished = False
        self.deck = [(r, s) for r in RANKS for s in SUITS]
        random.shuffle(self.deck)
        self.player = [self.deck.pop(), self.deck.pop()]
        self.dealer = [self.deck.pop(), self.deck.pop()]

    def embed(self, result=None, kind="info"):
        e = discord.Embed(
            title="🃏 Blackjack" if result is None else f"🃏 {result[0]}",
            colour=COLORS["info"] if result is None else COLORS[kind],
        )
        e.add_field(
            name=f"🙋 Your hand ({hand_value(self.player)})",
            value=show_hand(self.player), inline=False,
        )
        if result is None:
            e.add_field(name="🎩 Dealer", value=f"{show_hand(self.dealer[:1])} `??`", inline=False)
            e.description = "*Hit for another card, or stand and let the dealer play.*"
        else:
            e.add_field(
                name=f"🎩 Dealer ({hand_value(self.dealer)})",
                value=show_hand(self.dealer), inline=False,
            )
            e.description = result[1]
        e.set_footer(text=f"Bet: {self.bet:,} M")
        return e

    def settle(self):
        """Dealer plays, winnings are paid. Returns ((title, text), kind)."""
        self.finished = True
        pv = hand_value(self.player)
        if pv <= 21:
            while hand_value(self.dealer) < 17:
                self.dealer.append(self.deck.pop())
        dv = hand_value(self.dealer)
        if pv > 21:
            payout, kind = 0, "bad"
            res = ("Bust!", f"*{random.choice(BJ_BUST)}* You lose **{self.bet:,}** M.")
        elif dv > 21 or pv > dv:
            payout, kind = self.bet * 2, "ok"
            why = "The dealer busted. " if dv > 21 else ""
            res = ("You win!", f"{why}*{random.choice(BJ_WIN)}* **+{self.bet:,}** M.")
        elif pv == dv:
            payout, kind = self.bet, "warn"
            res = ("Push!", "Dead even, so your bet is returned.")
        else:
            payout, kind = 0, "bad"
            res = ("Dealer wins", f"*{random.choice(BJ_LOSE)}* You lose **{self.bet:,}** M.")
        me = get_user(self.user_id)
        me["medals"] += payout
        record_gamble(me, payout - self.bet)    # win +bet, push 0, loss -bet
        save()
        return res, kind

    async def interaction_check(self, interaction):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This isn't your game.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Hit", emoji="🃏", style=discord.ButtonStyle.primary)
    async def hit(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.finished:
            return
        self.player.append(self.deck.pop())
        if hand_value(self.player) >= 21:
            res, kind = self.settle()
            self.stop()
            await interaction.response.edit_message(embed=self.embed(res, kind), view=None)
        else:
            await interaction.response.edit_message(embed=self.embed(), view=self)

    @discord.ui.button(label="Stand", emoji="✋", style=discord.ButtonStyle.secondary)
    async def stand(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.finished:
            return
        res, kind = self.settle()
        self.stop()
        await interaction.response.edit_message(embed=self.embed(res, kind), view=None)

    async def on_timeout(self):
        if self.finished:
            return
        (title, text), kind = self.settle()
        try:
            await self.interaction.edit_original_response(
                embed=self.embed((title, text + "\n*(auto-stand: time ran out)*"), kind), view=None
            )
        except discord.HTTPException:
            pass


@bot.tree.command(name="blackjack", description="Play Blackjack against the dealer!")
@app_commands.describe(bet="Medals to bet")
async def blackjack(interaction: discord.Interaction, bet: app_commands.Range[int, 1]):
    me = get_user(interaction.user.id)
    if bet > me["medals"]:
        await deny(interaction, f"You only have **{me['medals']:,}** M in your wallet.")
        return
    me["medals"] -= bet  # the bet is held until the hand ends
    save()
    view = BlackjackView(interaction, bet)
    if hand_value(view.player) == 21:  # natural blackjack
        view.finished = True
        if hand_value(view.dealer) == 21:
            me["medals"] += bet
            res, kind = ("Push!", "Both of you have blackjack. Your bet is returned."), "warn"
        else:
            bonus = int(bet * 1.5)
            me["medals"] += bet + bonus
            record_gamble(me, bonus)
            res, kind = ("BLACKJACK!", f"A natural 21! **+{bonus:,}** M."), "gold"
        save()
        await interaction.response.send_message(embed=view.embed(res, kind))
        return
    await interaction.response.send_message(embed=view.embed(), view=view)


# ---------------------------------------------------------------------------
# /bank ...
# ---------------------------------------------------------------------------
bank_group = app_commands.Group(name="bank", description="Medal bank and vault")


@bank_group.command(name="create", description=f"Create a bank account (costs {BANK_FEE} medals)")
@app_commands.describe(password="Your vault password. Do NOT reuse a real password!")
async def bank_create(interaction: discord.Interaction, password: app_commands.Range[str, 4, 32]):
    me = get_user(interaction.user.id)
    if me["bank"]:
        await deny(interaction, "You already have a bank account.")
        return
    if me["medals"] < BANK_FEE:
        await deny(interaction, f"Opening an account costs **{BANK_FEE}** M. You have {me['medals']:,} M.")
        return
    me["medals"] -= BANK_FEE
    me["bank"] = make_bank(password)
    save()
    await say(
        interaction, "🏦 Welcome to the Why Bank!",
        "Your vault is open for business. Only you (and lucky guessers) hold the key.",
        "ok", ephemeral=True,
        fields=[("🔐 Vault cap", f"{TIERS[0][0]:,} M", True), ("📈 Interest", "1% per day", True)],
        footer="Remember your password. It protects you from robbers.",
    )


@bank_group.command(name="deposit", description="Deposit medals into your bank")
@app_commands.describe(amount="Medals to move from your wallet to your vault")
async def bank_deposit(interaction: discord.Interaction, amount: app_commands.Range[int, 1]):
    me, b = await need_bank(interaction)
    if not b:
        return
    if amount > me["medals"]:
        await deny(interaction, f"You only have **{me['medals']:,}** M in your wallet.")
        return
    space = vault_cap(b) - b["vault"]
    if amount > space:
        await deny(interaction, f"Your vault only has room for **{space:,}** M. Try `/bank upgrade`!")
        return
    me["medals"] -= amount
    b["vault"] += amount
    save()
    await say(
        interaction, "📥 Deposit complete", f"**{amount:,}** M tucked safely into the vault.", "ok",
        ephemeral=True,
        fields=[("🏦 Vault", f"`{meter(b['vault'], vault_cap(b))}`\n{b['vault']:,} / {vault_cap(b):,} M", True),
                ("👛 Wallet", f"{me['medals']:,} M", True)],
    )


@bank_group.command(name="withdraw", description="Withdraw medals from your bank")
@app_commands.describe(amount="Medals to move from your vault to your wallet")
async def bank_withdraw(interaction: discord.Interaction, amount: app_commands.Range[int, 1]):
    me, b = await need_bank(interaction)
    if not b:
        return
    if amount > b["vault"]:
        await deny(interaction, f"Your vault only holds **{b['vault']:,}** M.")
        return
    b["vault"] -= amount
    me["medals"] += amount
    save()
    await say(
        interaction, "📤 Withdrawal complete", f"**{amount:,}** M back in your pocket.", "ok",
        ephemeral=True,
        fields=[("🏦 Vault", f"{b['vault']:,} M", True), ("👛 Wallet", f"{me['medals']:,} M", True)],
    )


@bank_group.command(name="loan", description="Take a loan from the bank")
@app_commands.describe(amount="Medals to borrow (up to half your vault cap)")
async def bank_loan(interaction: discord.Interaction, amount: app_commands.Range[int, 1]):
    me, b = await need_bank(interaction)
    if not b:
        return
    if b["loan"] > 0:
        await deny(interaction, f"Repay your current loan (**{b['loan']:,}** M) first.")
        return
    max_loan = vault_cap(b) // 2
    if amount > max_loan:
        await deny(interaction, f"At your vault tier you can borrow up to **{max_loan:,}** M.")
        return
    owed = amount + int(amount * LOAN_FEE)
    b["loan"] = owed
    b["due"] = time.time() + LOAN_DAYS * DAY
    b["penalized"] = False
    me["medals"] += amount
    save()
    await say(
        interaction, "💳 Loan approved", f"The bank hands you **{amount:,}** M. Spend it wisely.", "warn",
        ephemeral=True,
        fields=[("📜 You owe", f"{owed:,} M", True), ("⏰ Due", ts(b["due"]), True)],
        footer=f"Late loans get a {int(LOAN_FEE * 100)}% penalty.",
    )


@bank_group.command(name="repay", description="Repay your bank loan")
@app_commands.describe(amount="Medals to pay back")
async def bank_repay(interaction: discord.Interaction, amount: app_commands.Range[int, 1]):
    me, b = await need_bank(interaction)
    if not b:
        return
    if b["loan"] <= 0:
        await deny(interaction, "You don't have a loan. Nice and debt-free!")
        return
    if amount > me["medals"]:
        await deny(interaction, f"You only have **{me['medals']:,}** M in your wallet.")
        return
    pay = min(amount, b["loan"])
    me["medals"] -= pay
    b["loan"] -= pay
    if b["loan"] == 0:
        b["due"] = 0
        b["penalized"] = False
    save()
    if b["loan"]:
        await say(interaction, "💳 Payment received", f"Paid **{pay:,}** M. Still owed: **{b['loan']:,}** M.",
                  "info", ephemeral=True)
    else:
        await say(interaction, "🎉 Debt-free!", f"Paid **{pay:,}** M. Your loan is fully repaid.",
                  "ok", ephemeral=True)


@bank_group.command(name="upgrade", description="Upgrade your vault tier (raises your interest cap up to 1M)")
async def bank_upgrade(interaction: discord.Interaction):
    me, b = await need_bank(interaction)
    if not b:
        return
    if b["tier"] >= len(TIERS) - 1:
        await deny(interaction, "Your vault is already at the maximum tier. Absolute unit.")
        return
    new_cap, cost = TIERS[b["tier"] + 1]
    if me["medals"] < cost:
        await deny(interaction, f"The next tier ({new_cap:,} M cap) costs **{cost:,}** M. You have {me['medals']:,} M.")
        return
    me["medals"] -= cost
    b["tier"] += 1
    save()
    await say(
        interaction, "🔒 Vault upgraded!",
        f"{interaction.user.mention} reinforced their vault. Bigger walls, bigger interest!", "gold",
        fields=[("🏦 Tier", f"**{b['tier']}** / {len(TIERS) - 1}", True),
                ("📦 New cap", f"**{new_cap:,}** M", True),
                ("💸 Cost", f"{cost:,} M", True)],
    )


@bank_group.command(name="changepassword", description="Change your bank password")
@app_commands.describe(old="Current password", new="New password")
async def bank_changepassword(
    interaction: discord.Interaction,
    old: str,
    new: app_commands.Range[str, 4, 32],
):
    me, b = await need_bank(interaction)
    if not b:
        return
    if not check_pw(b, old):
        await deny(interaction, "That's not your current password.")
        return
    salt = secrets.token_hex(16)
    b["salt"], b["hash"] = salt, hash_pw(new, salt)
    save()
    await say(interaction, "🔑 Password changed", "Your vault has a fresh lock.", "ok", ephemeral=True)


@bank_group.command(name="rob", description="Try to rob a player's bank vault by guessing their password")
@app_commands.describe(target="Whose vault to crack", password="Your guess")
async def bank_rob(interaction: discord.Interaction, target: discord.Member, password: str):
    me = get_user(interaction.user.id)
    now = time.time()
    if now < me["last_rob"] + ROB_COOLDOWN:
        await cooldown(interaction, "🚔 The heat is on", me["last_rob"] + ROB_COOLDOWN)
        return
    if target.bot or target.id == interaction.user.id:
        await deny(interaction, "Pick another player.")
        return
    victim = get_user(target.id)
    if not victim["bank"]:
        await deny(interaction, f"{target.display_name} doesn't even have a bank account.")
        return
    vb = victim["bank"]
    refresh_bank(vb)
    if vb["vault"] < 1_000:
        await deny(interaction, "Their vault is basically empty. Not worth the risk.")
        return
    if me["medals"] < ROB_FEE:
        await deny(interaction, f"You need **{ROB_FEE:,}** M in your wallet to cover bail if it goes wrong.")
        return
    me["last_rob"] = now
    if check_pw(vb, password):
        loot = min(int(vb["vault"] * 0.25), 250_000)
        vb["vault"] -= loot
        me["medals"] += loot
        save()
        await say(
            interaction, "🦹 VAULT CRACKED!",
            f"{interaction.user.mention} guessed {target.mention}'s password and walked off with the goods!",
            "bad", content=target.mention,
            fields=[("💰 Stolen", f"**{loot:,}** M", True)],
            footer="Change your password after a hit: /bank changepassword",
        )
    else:
        me["medals"] -= ROB_FEE
        victim["medals"] += ROB_FEE
        save()
        await say(
            interaction, "🔒 Wrong password!",
            f"{interaction.user.mention} tried to crack {target.mention}'s vault and set off the alarm.",
            "ok", content=target.mention,
            fields=[("🚓 Bail paid", f"**{ROB_FEE:,}** M, straight to {target.display_name}", False)],
        )


class WipeView(discord.ui.View):
    def __init__(self, owner_id):
        super().__init__(timeout=30)
        self.owner_id = owner_id

    async def interaction_check(self, interaction):
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Only the server owner can use this.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Yes, wipe everything", emoji="💥", style=discord.ButtonStyle.danger)
    async def yes(self, interaction: discord.Interaction, button: discord.ui.Button):
        save()
        backup = f"data-backup-{int(time.time())}.json"
        if os.path.exists(DB_FILE):
            shutil.copy(DB_FILE, backup)
        db["users"] = {}
        save()
        self.stop()
        await interaction.response.edit_message(
            embed=make_embed(
                "💥 Economy wiped",
                f"All banks, loans and balances are gone. A backup was saved as `{backup}`.",
                "bad",
            ),
            view=None,
        )

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.stop()
        await interaction.response.edit_message(
            embed=make_embed("😮‍💨 Cancelled", "Nothing was changed.", "ok"), view=None
        )


@bank_group.command(name="resetall", description="[OWNER ONLY] Wipe all banks, loans, and economy balances")
async def bank_resetall(interaction: discord.Interaction):
    if not is_owner(interaction):
        await deny(interaction, "Only the server owner can do this.")
        return
    await say(
        interaction, "⚠️ Wipe the whole economy?",
        "This deletes **every** balance, bank and loan. A backup file is saved first.\nAre you sure?",
        "warn", ephemeral=True, view=WipeView(interaction.user.id),
    )


# ---------------------------------------------------------------------------
# /mayor ...
# ---------------------------------------------------------------------------
mayor_group = app_commands.Group(name="mayor", description="Mayor powers")


@mayor_group.command(name="salary", description="Collect the mayor's paycheck")
async def mayor_salary(interaction: discord.Interaction):
    if not is_mayor(interaction):
        await deny(interaction, "Only the Mayor can collect this paycheck.")
        return
    me = get_user(interaction.user.id)
    now = time.time()
    if now < me["last_salary"] + DAY:
        await cooldown(interaction, "⏳ Treasury is closed", me["last_salary"] + DAY)
        return
    me["last_salary"] = now
    me["medals"] += MAYOR_SALARY
    save()
    await say(
        interaction, "🏛️ Mayoral paycheck collected",
        "*The City Treasury stamps your voucher with a flourish.*", "gold",
        fields=[("💰 Salary", f"+**{MAYOR_SALARY:,}** M", True), ("👛 Wallet", f"**{me['medals']:,}** M", True)],
    )


@mayor_group.command(name="tax", description=f"Set the market tax charged on /transfer (0-{MAX_TAX}%)")
@app_commands.describe(percent=f"New tax rate in percent (0-{MAX_TAX})")
async def mayor_tax(interaction: discord.Interaction, percent: app_commands.Range[int, 0, MAX_TAX]):
    if not is_mayor(interaction):
        await deny(interaction, "Only the Mayor can set the market tax.")
        return
    old = db["tax"]
    db["tax"] = percent
    save()
    await say(
        interaction, "🏛️ Market tax updated",
        f"By decree of Mayor {interaction.user.mention}, every `/transfer` now carries a **{percent}%** tax.", "gold",
        fields=[("📉 Before", f"{old}%", True), ("📈 Now", f"**{percent}%**", True)],
        footer=f"Resets to {DEFAULT_TAX}% when the Mayor's term ends.",
    )


@mayor_group.command(name="award", description="Honor a supporter with the Key to the City")
@app_commands.describe(member="Who to honor")
async def mayor_award(interaction: discord.Interaction, member: discord.Member):
    if not is_mayor(interaction):
        await deny(interaction, "Only the Mayor can hand out this honor.")
        return
    if member.bot or member.id == interaction.user.id:
        await deny(interaction, "Pick another member.")
        return
    get_user(member.id)["medals"] += 15_000
    save()
    await say(
        interaction, "🗝️ Key to the City",
        f"By decree of Mayor {interaction.user.mention}, {member.mention} is honored for their loyal support!",
        "gold", content=member.mention,
        fields=[("🎁 Reward", "+**15,000** M", True)],
    )


elect_group = app_commands.Group(name="elect", description="Appoint a Mayor")


@elect_group.command(name="mayor", description="[Server Owner] Appoint a Mayor immediately")
@app_commands.describe(member="Who becomes Mayor")
async def elect_mayor(interaction: discord.Interaction, member: discord.Member):
    if not is_owner(interaction):
        await deny(interaction, "Only the server owner can appoint a Mayor.")
        return
    if member.bot:
        await deny(interaction, "Bots can't be Mayor.")
        return
    await interaction.response.defer()
    try:
        await set_mayor(interaction.guild, member)
    except discord.HTTPException as e:
        await follow(
            interaction, "⚠️ Couldn't assign the role",
            f"{e}\nGive my role *Manage Roles* and move it above the **{MAYOR_ROLE}** role.", "bad",
        )
        return
    await follow(
        interaction, "👑 A new Mayor is appointed!",
        f"{member.mention} now leads the city for **{TERM_DAYS} days**.", "gold",
    )


end_group = app_commands.Group(name="end", description="End terms early")


@end_group.command(name="mayorterm", description="[Server Owner] End the current Mayor's term immediately")
async def end_mayorterm(interaction: discord.Interaction):
    if not is_owner(interaction):
        await deny(interaction, "Only the server owner can do that.")
        return
    if not db["mayor"]:
        await deny(interaction, "There's no sitting Mayor.")
        return
    await interaction.response.defer()
    who = db["mayor"]["id"]
    await clear_mayor(interaction.guild)
    await follow(interaction, "🏛️ Term ended", f"<@{who}>'s time as Mayor is over.", "warn")


# ---------------------------------------------------------------------------
# /election ...
# ---------------------------------------------------------------------------
election_group = app_commands.Group(name="election", description="Mayoral elections")


@election_group.command(name="start", description="[Admin/Staff] Manually trigger a fresh 48-hour Mayoral election cycle")
async def election_start(interaction: discord.Interaction):
    if not is_staff(interaction):
        await deny(interaction, "Admins and staff only.")
        return
    if db["election"]:
        await deny(interaction, "An election is already running.")
        return
    ends = time.time() + ELECTION_HOURS * 3600
    db["election"] = {
        "ends": ends, "channel_id": interaction.channel_id,
        "candidates": {}, "votes": {}, "banned": [], "url": None,
    }
    db["announce_channel"] = interaction.channel_id
    save()
    await say(
        interaction, "🗳️ The Mayoral election has begun!",
        "The city needs a leader. Will it be you?", "gold",
        fields=[
            ("⏰ Polls close", ts(ends), False),
            ("🎤 Want to run?", f"`/election register` ({CANDIDATE_FEE:,} M, max {MAX_CANDIDATES} candidates)", False),
            ("🙋 Want to vote?", "`/election vote` (one ballot each)", False),
        ],
    )
    try:
        message = await interaction.original_response()
        db["election"]["url"] = message.jump_url
        save()
    except discord.HTTPException:
        pass


@election_group.command(name="register", description=f"Register as an official candidate for Mayor (Cost: {CANDIDATE_FEE:,} Medals, Max {MAX_CANDIDATES})")
async def election_register(interaction: discord.Interaction):
    el = await open_election(interaction)
    if not el:
        return
    uid = str(interaction.user.id)
    if uid in el["candidates"]:
        await deny(interaction, "You're already on the ballot.")
        return
    if len(el["candidates"]) >= MAX_CANDIDATES:
        await deny(interaction, f"The ballot is full ({MAX_CANDIDATES} candidates).")
        return
    me = get_user(interaction.user.id)
    if me["medals"] < CANDIDATE_FEE:
        await deny(interaction, f"Running costs **{CANDIDATE_FEE:,}** M. You have {me['medals']:,} M.")
        return
    me["medals"] -= CANDIDATE_FEE
    el["candidates"][uid] = {"registered": time.time()}
    save()
    await say(
        interaction, "🎤 A new candidate enters the race!",
        f"{interaction.user.mention} is running for Mayor!", "gold",
        fields=[("📋 Candidates", f"{len(el['candidates'])} / {MAX_CANDIDATES}", True),
                ("🗳️ Support them", "`/election vote`", True)],
    )


@election_group.command(name="vote", description="Cast your ballot for a registered Mayoral candidate")
@app_commands.describe(candidate="The candidate you are voting for")
async def election_vote(interaction: discord.Interaction, candidate: discord.Member):
    el = await open_election(interaction)
    if not el:
        return
    if str(candidate.id) not in el["candidates"]:
        await deny(interaction, "That person isn't a registered candidate.")
        return
    if interaction.user.id in el["banned"]:
        await deny(interaction, "Your earlier ballot was removed by staff, so you can't vote again.")
        return
    voter = str(interaction.user.id)
    if voter in el["votes"]:
        await deny(interaction, "You've already cast your ballot.")
        return
    joined = interaction.user.joined_at
    el["votes"][voter] = {
        "cand": candidate.id,
        "t": time.time(),
        "acct": interaction.user.created_at.timestamp(),
        "joined": joined.timestamp() if joined else 0,
    }
    save()
    await say(
        interaction, "✅ Ballot cast!", f"Your vote for **{candidate.display_name}** has been counted.",
        "ok", ephemeral=True, footer="Ballots are final.",
    )


@election_group.command(name="status", description="View current Mayoral election status, countdown, registered candidates, and ballots")
async def election_status(interaction: discord.Interaction):
    el = db["election"]
    fields = []
    if el:
        counts = tally(el)
        total = max(len(el["votes"]), 1)
        desc = f"Polls close {ts(el['ends'])}\n🗳️ Ballots cast: **{len(el['votes'])}**"
        if counts:
            lines = [
                f"<@{c}>: **{n}** vote(s)\n`{meter(n, total, 12)}`"
                for c, n in sorted(counts.items(), key=lambda kv: -kv[1])
            ]
            fields.append(("🎤 Candidates", "\n".join(lines), False))
        else:
            fields.append(("🎤 Candidates", "Nobody has registered yet. Be the first!", False))
    else:
        desc = "No election is running right now."
    m = db["mayor"]
    if m:
        fields.append(("👑 Current Mayor", f"<@{m['id']}>\nterm ends {ts(m['term_end'])}", False))
    await say(interaction, "🗳️ Mayoral election", desc, "gold", fields=fields)


@election_group.command(name="audit", description="[Admin/Staff] Audit active election votes to detect alts and fraudulent ballots")
async def election_audit(interaction: discord.Interaction):
    if not is_staff(interaction):
        await deny(interaction, "Admins and staff only.")
        return
    el = db["election"]
    if not el:
        await deny(interaction, "No election is running.")
        return
    flagged = flag_votes(el)
    if not flagged:
        await say(interaction, "🕵️ Audit complete",
                  f"Checked **{len(el['votes'])}** ballot(s). Nothing suspicious.", "ok", ephemeral=True)
        return
    lines = [
        f"<@{vid}> → <@{el['votes'][vid]['cand']}>\n└ {', '.join(reasons)}"
        for vid, reasons in flagged.items()
    ]
    shown = lines[:12]
    if len(lines) > 12:
        shown.append(f"...and {len(lines) - 12} more")
    await say(
        interaction, f"🕵️ {len(flagged)} of {len(el['votes'])} ballots flagged",
        "\n".join(shown), "warn", ephemeral=True,
        footer="These are rough signals. Review before using /election purge_alts.",
    )


@election_group.command(name="purge_alts", description="[Admin/Staff] Automatically purge flagged alt votes and restore accurate candidate totals")
async def election_purge(interaction: discord.Interaction):
    if not is_staff(interaction):
        await deny(interaction, "Admins and staff only.")
        return
    el = db["election"]
    if not el:
        await deny(interaction, "No election is running.")
        return
    flagged = flag_votes(el)
    for vid in flagged:
        del el["votes"][vid]
        el["banned"].append(int(vid))
    save()
    await say(interaction, "🧹 Ballots purged",
              f"Removed **{len(flagged)}** flagged ballot(s). Candidate totals are up to date.",
              "ok", ephemeral=True)


@election_group.command(name="end", description="[Admin/Staff] Force-conclude the active election immediately and crown the winner")
async def election_end(interaction: discord.Interaction):
    if not is_staff(interaction):
        await deny(interaction, "Admins and staff only.")
        return
    if not db["election"]:
        await deny(interaction, "No election is running.")
        return
    await interaction.response.defer()
    embed = await conclude_election(interaction.guild)
    await interaction.followup.send(embed=embed)


@election_group.command(name="broadcast_dm", description="[Admin Only] Safely DM server members with link to election announcement")
@app_commands.describe(
    confirm="Set to True to really send",
    link="Link to include (defaults to the election announcement)",
)
async def election_broadcast(
    interaction: discord.Interaction, confirm: bool, link: Optional[str] = None
):
    if not is_admin(interaction):
        await deny(interaction, "Admins only.")
        return
    if not bot.intents.members:
        await deny(
            interaction,
            "This needs the **Server Members Intent**. Enable it in the Developer Portal "
            "(Bot tab), add `MEMBERS_INTENT=1` to your .env, and restart the bot.",
        )
        return
    el = db["election"]
    url = link or (el.get("url") if el else None)
    if not url:
        await deny(interaction, "No link to send. Start an election first or pass a link.")
        return
    if not confirm:
        await deny(interaction, "Set `confirm` to **True** to send. This DMs every member.")
        return
    members = [m for m in interaction.guild.members if not m.bot]
    await say(
        interaction, "📨 Broadcast started",
        f"Sending DMs to **{len(members)}** member(s), one every 2 seconds. I'll post here when it's done.",
        "info",
    )
    channel, guild_name = interaction.channel, interaction.guild.name
    dm = make_embed(
        f"🗳️ {guild_name}: the Mayoral election is on!",
        f"Candidates are running and every vote counts.\n[Open the announcement]({url})",
        "gold",
    )

    async def run():
        sent = failed = 0
        for m in members:
            try:
                await m.send(embed=dm)
                sent += 1
            except discord.HTTPException:
                failed += 1  # DMs closed
            await asyncio.sleep(2)  # slow on purpose so Discord doesn't flag the bot
        await channel.send(embed=make_embed(
            "📨 Broadcast finished", f"✅ **{sent}** delivered · 🚫 **{failed}** couldn't be reached", "ok"
        ))

    task = asyncio.create_task(run())
    bg_tasks.add(task)
    task.add_done_callback(bg_tasks.discard)


# ---------------------------------------------------------------------------
# /dice, Virtual Earth (/harvest /treasury /policy) and the Market Bank (/marketbank)
# ---------------------------------------------------------------------------
def dice_line(d):
    return f"🎲 {d[0]} + {d[1]} = **{sum(d)}**"


@bot.tree.command(name="dice", description=f"Roll two dice against the house. Beat its total to win 2x (min bet {DICE_MIN_BET:,})")
@app_commands.describe(bet="Medals to bet")
async def dice(interaction: discord.Interaction, bet: app_commands.Range[int, DICE_MIN_BET]):
    try:
        r = play_dice(interaction.user.id, bet)
    except TradeError as e:
        await deny(interaction, str(e))
        return
    rolls = [("🧑 You", dice_line(r["you"]), True), ("🏠 House", dice_line(r["house"]), True)]
    wallet = ("👛 Wallet", f"**{r['wallet']:,}** M", True)
    if r["result"] == "win":
        final = make_embed("🎲 You win!", "Your dice beat the house.", "ok",
                           fields=rolls + [("💰 Won", f"+**{r['bet']:,}** M", True), wallet])
    else:
        why = "A tie goes to the house." if r["result"] == "tie" else "The house rolled higher."
        final = make_embed("🎲 The house wins", why, "bad",
                           fields=rolls + [("💸 Lost", f"-**{r['bet']:,}** M", True), wallet])
    await say(interaction, "🎲 Rolling...",
              f"*{interaction.user.display_name} bets **{r['bet']:,}** M. The dice tumble...*", "warn")
    await asyncio.sleep(1.3)
    await interaction.edit_original_response(embed=final)


NO_LAND = "You don't rule any land yet. Claim one on the website's Virtual Earth map first."


@bot.tree.command(name="harvest", description="Collect the yield your Virtual Earth land has built up into your treasury")
async def harvest(interaction: discord.Interaction):
    codes = owned_codes(interaction.user.id)
    if not codes:
        await deny(interaction, NO_LAND)
        return
    total = treasury = 0
    last_error = None
    for code in codes:
        try:
            r = harvest_land(interaction.user.id, code)
        except TradeError as e:
            last_error = e
            continue
        total += r["harvested"]
        treasury += r["treasury"]
    if not total:
        await deny(interaction, str(last_error))
        return
    await say(
        interaction, "🌾 Harvest collected", "*Your land's yield rolls into the national treasury.*", "ok",
        fields=[("💰 Harvested", f"+**{total:,}** M", True), ("🏛️ Treasury", f"**{treasury:,}** M", True)],
        footer="Move medals to your wallet with /treasury withdraw.",
    )


treasury_group = app_commands.Group(name="treasury", description="Your nation's treasury")


@treasury_group.command(name="deposit", description="Move medals from your wallet into your nation's treasury")
@app_commands.describe(amount="Medals to move")
async def treasury_deposit(interaction: discord.Interaction, amount: app_commands.Range[int, 1]):
    codes = owned_codes(interaction.user.id)
    if not codes:
        await deny(interaction, NO_LAND)
        return
    try:
        r = move_treasury(interaction.user.id, codes[0], "deposit", amount)
    except TradeError as e:
        await deny(interaction, str(e))
        return
    await say(
        interaction, "🏛️ Treasury funded", None, "ok",
        fields=[("📥 Moved in", f"**{r['amount']:,}** M", True), ("🏛️ Treasury", f"**{r['treasury']:,}** M", True),
                ("👛 Wallet", f"**{r['wallet']:,}** M", True)],
    )


@treasury_group.command(name="withdraw", description="Move medals from your nation's treasury into your wallet")
@app_commands.describe(amount="Medals to move")
async def treasury_withdraw(interaction: discord.Interaction, amount: app_commands.Range[int, 1]):
    codes = owned_codes(interaction.user.id)
    if not codes:
        await deny(interaction, NO_LAND)
        return
    try:
        r = move_treasury(interaction.user.id, codes[0], "withdraw", amount)
    except TradeError as e:
        await deny(interaction, str(e))
        return
    await say(
        interaction, "🏛️ Treasury withdrawal", None, "ok",
        fields=[("📤 Moved out", f"**{r['amount']:,}** M", True), ("🏛️ Treasury", f"**{r['treasury']:,}** M", True),
                ("👛 Wallet", f"**{r['wallet']:,}** M", True)],
    )


POLICY_CHOICES = [
    app_commands.Choice(name=f"{spec['label']}: {o['name']}", value=f"{cat}:{o['id']}")
    for cat, spec in POLICIES.items() for o in spec["options"]
]


@bot.tree.command(name="policy", description="Change one of your nation's policies (each category can change once an hour)")
@app_commands.describe(choice="The policy to adopt")
@app_commands.choices(choice=POLICY_CHOICES)
async def policy_cmd(interaction: discord.Interaction, choice: app_commands.Choice[str]):
    codes = owned_codes(interaction.user.id)
    if not codes:
        await deny(interaction, NO_LAND)
        return
    cat, _, value = choice.value.partition(":")
    try:
        r = set_policy(interaction.user.id, codes[0], cat, value)
    except TradeError as e:
        await deny(interaction, str(e))
        return
    await say(
        interaction, "📜 Policy adopted", f"**{r['label']}** is now **{r['name']}**.", "gold",
        fields=[("✨ Effect", r["desc"], False)],
        footer=f"Yield already earned was banked at the old rate. This category can change again in {POLICY_COOLDOWN // 3600}h.",
    )


marketbank_group = app_commands.Group(
    name="marketbank", description="The Market Bank where tax and trading fees go (Mayor, Owner, Administrators)")


async def need_market_bank(interaction):
    if not can_use_market_bank(interaction.user, interaction.guild):
        await deny(interaction, "Only the Mayor, the Owner and Administrators can use the Market Bank.")
        return False
    return True


@marketbank_group.command(name="balance", description="See what the Market Bank holds")
async def marketbank_balance(interaction: discord.Interaction):
    if not await need_market_bank(interaction):
        return
    b = market_bank_json()
    await say(
        interaction, "🏦 Market Bank", "Where the market tax and trading fees go.", "gold", ephemeral=True,
        fields=[("💰 Balance", f"**{b['balance']:,}** M", True),
                ("🧾 From /transfer tax", f"{b['in']['transfer']:,} M", True),
                ("📈 From stock fees", f"{b['in']['stock']:,} M", True),
                ("🏛️ Tax now", f"{b['tax']}%", True)],
    )


@marketbank_group.command(name="withdraw", description="Take medals out of the Market Bank into your wallet")
@app_commands.describe(amount="Medals to take out")
async def marketbank_withdraw(interaction: discord.Interaction, amount: app_commands.Range[int, 1]):
    if not await need_market_bank(interaction):
        return
    try:
        r = market_bank_move(interaction.user.id, interaction.user.name, "withdraw", amount)
    except TradeError as e:
        await deny(interaction, str(e))
        return
    await say(
        interaction, "🏦 Market Bank withdrawal", f"{interaction.user.mention} took medals out of the Market Bank.", "gold",
        fields=[("📤 Withdrawn", f"**{amount:,}** M", True), ("🏦 Bank now", f"**{r['balance']:,}** M", True),
                ("👛 Wallet", f"**{r['wallet']:,}** M", True)],
    )


@marketbank_group.command(name="deposit", description="Put medals from your wallet into the Market Bank")
@app_commands.describe(amount="Medals to put in")
async def marketbank_deposit(interaction: discord.Interaction, amount: app_commands.Range[int, 1]):
    if not await need_market_bank(interaction):
        return
    try:
        r = market_bank_move(interaction.user.id, interaction.user.name, "deposit", amount)
    except TradeError as e:
        await deny(interaction, str(e))
        return
    await say(
        interaction, "🏦 Market Bank deposit", f"{interaction.user.mention} put medals into the Market Bank.", "gold",
        fields=[("📥 Deposited", f"**{amount:,}** M", True), ("🏦 Bank now", f"**{r['balance']:,}** M", True),
                ("👛 Wallet", f"**{r['wallet']:,}** M", True)],
    )


# ---------------------------------------------------------------------------
# Website API (runs inside the bot, so the site and Discord share one wallet)
#   GET  /auth/login  /auth/callback  /auth/logout     Discord sign-in
#   GET  /api/me  /api/stocks  /api/leaderboard  /api/earth
#   POST /api/stocks/buy  /sell  /found
#   POST /api/earth/claim  /harvest  /policy
#   POST /api/earth/treasury/deposit  /withdraw
#   POST /api/casino/dice  /flip         GET /api/casino/blackjack  POST .../blackjack/deal  /hit  /stand
#   GET  /api/mayor    POST /api/election/register  /vote
#   POST /api/daily  /api/vault/deposit  /withdraw
#   POST /api/earth/action        every building, tax, army, spy, war, sealane and buyout move
#   GET  /api/admin/vaults                             Owner/Administrator only
#   GET  /api/marketbank                               Mayor, Owner and Administrators only
#   POST /api/marketbank/withdraw  /deposit            Mayor, Owner and Administrators only
#   POST /api/admin/stocks/price  /delist              Owner/Administrator only
# Rules: the server's clock is the only clock, every action is validated, every
# member is rate limited, and no number from the browser is trusted. The only
# thing the browser says about itself is the signed cookie.
# ---------------------------------------------------------------------------
class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def same(a, b):
    """Constant-time compare that also accepts non-ASCII text from the network."""
    return hmac.compare_digest(a.encode(), b.encode())


def sign(text):
    return hmac.new(SESSION_SECRET.encode(), text.encode(), hashlib.sha256).hexdigest()


def make_session(uid):
    body = f"{uid}.{int(time.time()) + SESSION_DAYS * DAY}"
    return f"{body}.{sign(body)}"


def session_uid(request):
    """The member id from the signed cookie, or None."""
    parts = request.cookies.get("why_session", "").split(".")
    if len(parts) != 3 or not parts[0].isdigit():
        return None
    uid, exp, sig = parts
    if not same(sig, sign(f"{uid}.{exp}")):
        return None
    if not exp.isdigit() or int(exp) < time.time():
        return None
    return int(uid)


_rate = {}


def client_ip(request):
    fwd = request.headers.get("CF-Connecting-IP") or request.headers.get("X-Forwarded-For", "")
    return fwd.split(",")[0].strip() or str(getattr(request, "remote", "")) or "?"


def rate_limit(uid, write):
    limit, window = RATE_WRITES if write else RATE_READS
    q = _rate.setdefault((uid, write), deque())
    now = time.time()
    while q and q[0] < now - window:
        q.popleft()
    if len(q) >= limit:
        raise ApiError(429, "Slow down a little.")
    q.append(now)


def check_origin(request):
    """Browsers always send Origin on POST. Refuse requests from other sites."""
    origin = request.headers.get("Origin")
    if origin is None:
        return
    allowed = {WEB_ORIGIN} if WEB_ORIGIN else set()
    allowed.add(WEB_BASE_URL)
    if origin.rstrip("/") not in allowed and urlparse(origin).netloc != request.host:
        raise ApiError(403, "Requests from other sites are not allowed.")


_staff_cache = {}


async def staff_uid(uid, cached=False):
    """Owner / Administrator check. Admin actions always ask fresh; `cached` is only for UI hints."""
    if cached and _staff_cache.get(uid, (0, False))[0] > time.time() - 60:
        return _staff_cache[uid][1]
    result = await staff_lookup(uid)
    _staff_cache[uid] = (time.time(), result)
    return result


async def staff_lookup(uid):
    guild = bot.get_guild(GUILD.id)
    if guild is None:
        return False
    try:
        m = guild.get_member(uid) or await guild.fetch_member(uid)
    except discord.HTTPException:
        return False
    return (m.id == guild.owner_id or m.guild_permissions.administrator
            or any(r.name in STAFF_ROLE for r in m.roles))


_bank_cache = {}


async def bank_uid(uid, cached=False):
    """Mayor / Owner / Administrator check for the Market Bank. `cached` is only for reads and UI hints."""
    if cached and _bank_cache.get(uid, (0, False))[0] > time.time() - 60:
        return _bank_cache[uid][1]
    result = await bank_lookup(uid)
    _bank_cache[uid] = (time.time(), result)
    return result


async def bank_lookup(uid):
    guild = bot.get_guild(GUILD.id)
    if guild is None:
        return False
    try:
        m = guild.get_member(uid) or await guild.fetch_member(uid)
    except discord.HTTPException:
        return False
    return can_use_market_bank(m, guild)


def api(*, write=False, staff=False, optional=False, bank=False):
    """Wraps a handler fn(uid, body) -> dict with login, origin, rate limit, staff and error handling."""
    def deco(fn):
        async def handler(request):
            try:
                uid = session_uid(request)
                if uid is None and not optional:
                    raise ApiError(401, "Log in with Discord first.")
                if write:
                    check_origin(request)
                    if request.content_type != "application/json":
                        raise ApiError(415, "Send JSON.")
                rate_limit(uid if uid is not None else "ip:" + client_ip(request), write)
                if staff and not await staff_uid(uid):
                    raise ApiError(403, "Owner or Administrator only.")
                if bank and not await bank_uid(uid, cached=not write):     # writes always ask Discord fresh
                    raise ApiError(403, "Only the Mayor, the Owner and Administrators can use the Market Bank.")
                body = {}
                if write:
                    try:
                        body = await request.json()
                    except Exception:
                        raise ApiError(400, "That wasn't valid JSON.")
                    if not isinstance(body, dict):
                        raise ApiError(400, "Expected a JSON object.")
                result = await fn(uid, body)
                return web.json_response(result, headers={"Cache-Control": "no-store"})
            except TradeError as e:
                return web.json_response({"error": str(e).replace("**", "")}, status=400)
            except ApiError as e:
                return web.json_response({"error": str(e)}, status=e.status)
            except Exception as e:
                print("api error:", repr(e))
                return web.json_response({"error": "Something went wrong."}, status=500)
        return handler
    return deco


# --- Leaderboards -----------------------------------------------------------
_names = {}                     # member id -> (expires, username, avatar url)
NAME_TTL = 10 * 60


async def member_card(uid):
    """Discord username (not the server nickname) and profile picture. Cached, so polling the leaderboard
    doesn't hammer Discord."""
    uid = int(uid)
    hit = _names.get(uid)
    if hit and hit[0] > time.time():
        return {"name": hit[1], "avatar": hit[2]}
    name = avatar = None
    guild = bot.get_guild(GUILD.id)
    if guild is not None:
        try:
            m = guild.get_member(uid) or await guild.fetch_member(uid)
            name = m.name
            avatar = m.display_avatar.with_size(64).url
        except Exception:
            name = avatar = None
    found = name is not None
    if not found:
        name = hit[1] if hit else f"Member {str(uid)[-4:]}"
        avatar = hit[2] if hit else None
    _names[uid] = (time.time() + (NAME_TTL if found else 60), name, avatar)     # retry a failed lookup soon
    return {"name": name, "avatar": avatar}


async def display_name(uid):
    return (await member_card(uid))["name"]


async def api_leaderboard(uid, body):
    """Public, like the market. Same numbers as /globallb plus casino results; the page never sees member ids."""
    users = db["users"]
    totals = sorted(((k, total_medals(u)) for k, u in users.items()), key=lambda r: r[1], reverse=True)
    circulation = sum(t for _, t in totals)
    rich = [r for r in totals if r[1] > 0][:LB_SIZE]
    bettors = sorted(
        ((k, u["gamble"]["won"], u["gamble"]["lost"]) for k, u in users.items()
         if isinstance(u.get("gamble"), dict) and u["gamble"]["won"] + u["gamble"]["lost"] > 0),
        key=lambda r: r[1] - r[2], reverse=True,
    )[:LB_SIZE]
    ids = list(dict.fromkeys([k for k, _ in rich] + [k for k, _, _ in bettors]))
    cards = dict(zip(ids, await asyncio.gather(*(member_card(i) for i in ids))))
    mine = str(uid) if uid is not None else None
    return {
        "medals": [{"name": cards[k]["name"], "avatar": cards[k]["avatar"], "medals": int(v), "me": k == mine}
                   for k, v in rich],
        "gamblers": [{"name": cards[k]["name"], "avatar": cards[k]["avatar"], "won": int(w), "lost": int(lo),
                      "me": k == mine} for k, w, lo in bettors],
        "circulation": int(circulation),
        "serverTime": int(time.time() * 1000),
    }


# --- Virtual Earth ----------------------------------------------------------
def earth_json(uid):
    """Who holds which land. Owners show by name; 'me' marks the viewer's own lands."""
    mine = str(uid) if uid is not None else None
    out = {}
    for c, l in db["earth"].items():
        if c not in EARTH_NATIONS:
            continue
        entry = {"name": l["name"], "me": l["owner"] == mine, "policy": dict(nation_state(l)["policy"]), **pub_json(l)}
        if entry["me"]:
            entry["nation"] = nation_json(c, l)      # treasury, yield, armies and cooldowns are only sent to the owner
        out[c] = entry
    return out


def claim_land(uid, name, code):
    """Plain function with no await, so the 'is it free?' check and the write can't be split by another request."""
    code = code.strip().upper() if isinstance(code, str) else ""
    if code not in EARTH_NATIONS:
        raise TradeError("There's no land with that code.")
    lands = db["earth"]
    if code in lands:
        raise ApiError(409, f"{EARTH_NATIONS[code]} has already been claimed.")
    held = sum(1 for l in lands.values() if l["owner"] == str(uid))
    if EARTH_MAX_PER_MEMBER and held >= EARTH_MAX_PER_MEMBER:
        raise TradeError(f"You already hold {held} free land{'s' if held != 1 else ''}. "
                         "More land comes by war or buyout.")
    lands[code] = {"owner": str(uid), "name": name, "at": time.time()}
    nation_state(lands[code])
    save()
    return code


async def api_earth(uid, body):
    world_tick()
    return {**earth_snapshot(uid), "maxLands": EARTH_MAX_PER_MEMBER, "policies": POLICIES, "catalog": catalog_json()}


async def api_earth_claim(uid, body):
    name = await display_name(uid)      # looked up first: nothing may await between the check and the write
    code = claim_land(uid, name, body.get("code"))
    print(f"member {uid} claimed {code}")
    return {"ok": True, "code": code, "claims": earth_json(uid)}


async def api_me(uid, body):
    return {"uid": str(uid), "wallet": get_user(uid)["medals"], "staff": await staff_uid(uid, cached=True),
            "bank": await bank_uid(uid, cached=True)}


async def api_stocks(uid, body):
    """Public: anyone can watch the market. Wallet and holdings only appear for a logged-in member."""
    out = {
        "stocks": stocks_json(),
        "fee": fee_rate(), "maxPerMember": STOCK_MAX_PER_MEMBER, "supply": STOCK_SUPPLY,
        "dividend": STOCK_DIVIDEND, "foundCost": STOCK_FOUND_COST, "serverTime": int(time.time() * 1000),
    }
    if uid is not None:
        out["wallet"] = get_user(uid)["medals"]
        out["holdings"] = holdings_json(uid)
        out["account"] = account_json(uid)       # vault and daily streak
    return out


def trade_result(r):
    return {"ok": True, "wallet": r["wallet"], "price": r["price"], "newPrice": r["new_price"],
            "fee": r["fee"], "total": r["total"], "held": r["held"]}


async def api_buy(uid, body):
    return trade_result(buy_shares(uid, body.get("ticker"), body.get("qty")))


async def api_sell(uid, body):
    return trade_result(sell_shares(uid, body.get("ticker"), body.get("qty")))


async def api_found(uid, body):
    r = found_company(uid, body.get("name"), body.get("ticker"), body.get("valuation"),
                      body.get("revenue"), body.get("profit"))
    return {"ok": True, **r}


async def api_admin_price(uid, body):
    r = set_stock_price(body.get("ticker"), body.get("price"))
    print(f"admin {uid} set {r['ticker']} price {r['old']:.2f} -> {r['price']:.2f}")
    return {"ok": True, **r}


async def api_admin_delist(uid, body):
    r = delist_stock(body.get("ticker"))
    print(f"admin {uid} delisted {r['ticker']}: {r['holders']} holder(s), {r['refunded']} M refunded")
    return {"ok": True, **r}


async def api_dice(uid, body):
    return {"ok": True, **play_dice(uid, body.get("bet"))}


async def api_marketbank(uid, body):
    return market_bank_json()


async def api_marketbank_withdraw(uid, body):
    name = await display_name(uid)      # looked up first: nothing may await between the check and the write
    return {"ok": True, **market_bank_move(uid, name, "withdraw", body.get("amount"))}


async def api_marketbank_deposit(uid, body):
    name = await display_name(uid)
    return {"ok": True, **market_bank_move(uid, name, "deposit", body.get("amount"))}


async def api_earth_harvest(uid, body):
    return {"ok": True, **harvest_land(uid, body.get("code")), "claims": earth_json(uid)}


async def api_earth_deposit(uid, body):
    return {"ok": True, **move_treasury(uid, body.get("code"), "deposit", body.get("amount")), "claims": earth_json(uid)}


async def api_earth_withdraw(uid, body):
    return {"ok": True, **move_treasury(uid, body.get("code"), "withdraw", body.get("amount")), "claims": earth_json(uid)}


async def api_earth_policy(uid, body):
    r = set_policy(uid, body.get("code"), body.get("category"), body.get("value"))
    return {"ok": True, **r, "claims": earth_json(uid)}


async def api_daily(uid, body):
    return {"ok": True, **claim_daily(uid)}


async def api_vault_deposit(uid, body):
    return {"ok": True, **vault_move(uid, "deposit", body.get("amount"))}


async def api_vault_withdraw(uid, body):
    return {"ok": True, **vault_move(uid, "withdraw", body.get("amount"))}


async def api_flip(uid, body):
    return {"ok": True, **flip_coin(uid, body.get("bet"), body.get("side"))}


async def api_bj_state(uid, body):
    return bj_state(uid)


async def api_bj_deal(uid, body):
    return bj_deal(uid, body.get("bet"))


async def api_bj_hit(uid, body):
    return bj_hit(uid)


async def api_bj_stand(uid, body):
    return bj_stand(uid)


async def api_earth_action(uid, body):
    name = await display_name(uid)          # looked up first: nothing may await between the check and the write
    other = None
    if body.get("action") == "offer_accept":
        o = find_offer(body.get("id"))
        if o is not None and o["kind"] == "buyout":
            other = await display_name(int(o["from"]))      # the buyer's current name becomes the land's ruler name
    msg = run_earth_action(uid, name, body, other)
    return {"ok": True, "message": msg, **earth_snapshot(uid), "wallet": get_user(uid)["medals"]}


async def api_mayor(uid, body):
    """Public. Same facts as /election status and /mayor, with names and pictures instead of mentions."""
    m = db["mayor"]
    el = db["election"]
    mayor_id = str(m["id"]) if m else None
    cand_ids = list(el["candidates"]) if el else []
    ids = list(dict.fromkeys(([mayor_id] if mayor_id else []) + cand_ids))
    cards = dict(zip(ids, await asyncio.gather(*(member_card(i) for i in ids))))
    mine = str(uid) if uid is not None else None
    out = {"salary": MAYOR_SALARY, "tax": db["tax"], "mayor": None, "election": None,
           "serverTime": int(time.time() * 1000)}
    if m:
        out["mayor"] = {"name": cards[mayor_id]["name"], "avatar": cards[mayor_id]["avatar"],
                        "me": mayor_id == mine, "termEnd": int(m["term_end"] * 1000)}
    if el:
        counts = tally(el)
        out["election"] = {
            "open": time.time() < el["ends"], "ends": int(el["ends"] * 1000),
            "max": MAX_CANDIDATES, "fee": CANDIDATE_FEE, "ballots": len(el["votes"]),
            "myVote": str(el["votes"][mine]["cand"]) if mine in el["votes"] else None,
            "banned": uid is not None and uid in el["banned"],
            "candidates": [{"id": c, "name": cards[c]["name"], "avatar": cards[c]["avatar"],
                            "votes": counts.get(c, 0), "me": c == mine, "incumbent": c == mayor_id}
                           for c in cand_ids],
        }
    return out


async def api_election_register(uid, body):
    return {"ok": True, **web_register(uid)}


async def api_election_vote(uid, body):
    created = ((uid >> 22) + 1420070400000) / 1000          # a Discord id carries the account's creation time
    joined = 0
    guild = bot.get_guild(GUILD.id)
    if guild is not None:
        try:
            m = guild.get_member(uid) or await guild.fetch_member(uid)
            joined = m.joined_at.timestamp() if m.joined_at else 0
        except discord.HTTPException:
            pass
    return {"ok": True, **web_vote(uid, body.get("candidate"), created, joined)}


async def api_admin_vaults(uid, body):
    """Every vault, richest first, for the Admin page. Passwords are hashed and never leave the bot."""
    rows = []
    for k, u in db["users"].items():
        b = u.get("bank")
        if b:
            refresh_bank(b)
            rows.append((k, int(b["vault"]), vault_cap(b), b["tier"], int(b["loan"])))
    rows.sort(key=lambda r: r[1], reverse=True)
    rows = rows[:50]
    cards = await asyncio.gather(*(member_card(r[0]) for r in rows))
    return {"vaults": [{"name": c["name"], "avatar": c["avatar"], "vault": r[1], "cap": r[2], "tier": r[3], "loan": r[4]}
                       for r, c in zip(rows, cards)]}


PAGE_HEADERS = {
    "X-Frame-Options": "DENY",                  # nobody can frame the page and trick clicks on Buy/Sell
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "same-origin",
    "Cache-Control": "no-cache",
}


async def hub_page(request):
    try:
        with open(HUB_FILE, "rb") as f:
            html = f.read()
    except OSError:
        return web.Response(status=404, text=f"Put the website page at {HUB_FILE} next to bot.py.")
    return web.Response(body=html, content_type="text/html", charset="utf-8", headers=PAGE_HEADERS)


async def auth_login(request):
    state = secrets.token_urlsafe(24)
    url = "https://discord.com/oauth2/authorize?" + urlencode({
        "client_id": CLIENT_ID, "redirect_uri": f"{WEB_BASE_URL}/auth/callback",
        "response_type": "code", "scope": "identify", "state": state, "prompt": "none",
    })
    resp = web.HTTPFound(url)
    resp.set_cookie("why_state", state, max_age=600, httponly=True, samesite="Lax",
                    secure=WEB_BASE_URL.startswith("https"))
    raise resp


async def auth_callback(request):
    state = request.query.get("state", "")
    code = request.query.get("code", "")
    if not code or not state or not same(state, request.cookies.get("why_state", "")):
        return web.Response(status=400, text="Login failed. Please try again.")
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15)) as http:
            async with http.post("https://discord.com/api/v10/oauth2/token", data={
                "client_id": CLIENT_ID, "client_secret": CLIENT_SECRET, "grant_type": "authorization_code",
                "code": code, "redirect_uri": f"{WEB_BASE_URL}/auth/callback",
            }) as r:
                token = (await r.json()).get("access_token") if r.status == 200 else None
            if not token:
                return web.Response(status=400, text="Discord refused the login. Please try again.")
            async with http.get("https://discord.com/api/v10/users/@me",
                                headers={"Authorization": f"Bearer {token}"}) as r:
                user = await r.json() if r.status == 200 else {}
        uid = int(user["id"])
    except (aiohttp.ClientError, asyncio.TimeoutError, KeyError, ValueError):
        return web.Response(status=502, text="Couldn't reach Discord. Please try again.")
    guild = bot.get_guild(GUILD.id)
    if guild is None:
        return web.Response(status=503, text="The bot is still starting. Try again in a moment.")
    try:
        await guild.fetch_member(uid)       # only members of the server get in
    except discord.NotFound:
        return web.Response(status=403, text="Join the Discord server first, then log in again.")
    except discord.HTTPException:
        return web.Response(status=502, text="Couldn't check your membership. Please try again.")
    resp = web.HTTPFound(WEB_HOME)
    resp.set_cookie("why_session", make_session(uid), max_age=SESSION_DAYS * DAY, httponly=True,
                    samesite="Lax", secure=WEB_BASE_URL.startswith("https"))
    resp.del_cookie("why_state")
    raise resp


async def auth_logout(request):
    resp = web.HTTPFound(WEB_HOME)
    resp.del_cookie("why_session")
    raise resp


@web.middleware
async def cors(request, handler):
    """Only needed when the hub page lives on a different origin than this API."""
    origin = request.headers.get("Origin", "").rstrip("/")
    allow = bool(WEB_ORIGIN) and origin == WEB_ORIGIN
    if request.method == "OPTIONS":
        resp = web.Response(status=204)
    else:
        try:
            resp = await handler(request)
        except web.HTTPException as e:
            resp = e
    if allow:
        resp.headers["Access-Control-Allow-Origin"] = origin
        resp.headers["Access-Control-Allow-Credentials"] = "true"
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        resp.headers["Vary"] = "Origin"
    return resp


def build_web_app():
    app = web.Application(middlewares=[cors], client_max_size=16 * 1024)
    app.router.add_get("/auth/login", auth_login)
    app.router.add_get("/auth/callback", auth_callback)
    app.router.add_get("/auth/logout", auth_logout)
    app.router.add_get("/api/me", api()(api_me))
    app.router.add_get("/api/stocks", api(optional=True)(api_stocks))
    app.router.add_get("/api/leaderboard", api(optional=True)(api_leaderboard))
    app.router.add_get("/api/earth", api(optional=True)(api_earth))
    app.router.add_post("/api/earth/claim", api(write=True)(api_earth_claim))
    app.router.add_post("/api/earth/harvest", api(write=True)(api_earth_harvest))
    app.router.add_post("/api/earth/treasury/deposit", api(write=True)(api_earth_deposit))
    app.router.add_post("/api/earth/treasury/withdraw", api(write=True)(api_earth_withdraw))
    app.router.add_post("/api/earth/policy", api(write=True)(api_earth_policy))
    app.router.add_post("/api/casino/dice", api(write=True)(api_dice))
    app.router.add_get("/api/marketbank", api(bank=True)(api_marketbank))
    app.router.add_post("/api/marketbank/withdraw", api(write=True, bank=True)(api_marketbank_withdraw))
    app.router.add_post("/api/marketbank/deposit", api(write=True, bank=True)(api_marketbank_deposit))
    app.router.add_get("/", hub_page)
    app.router.add_get("/api/mayor", api(optional=True)(api_mayor))
    app.router.add_post("/api/election/register", api(write=True)(api_election_register))
    app.router.add_post("/api/election/vote", api(write=True)(api_election_vote))
    app.router.add_post("/api/daily", api(write=True)(api_daily))
    app.router.add_post("/api/vault/deposit", api(write=True)(api_vault_deposit))
    app.router.add_post("/api/vault/withdraw", api(write=True)(api_vault_withdraw))
    app.router.add_post("/api/casino/flip", api(write=True)(api_flip))
    app.router.add_get("/api/casino/blackjack", api()(api_bj_state))
    app.router.add_post("/api/casino/blackjack/deal", api(write=True)(api_bj_deal))
    app.router.add_post("/api/casino/blackjack/hit", api(write=True)(api_bj_hit))
    app.router.add_post("/api/casino/blackjack/stand", api(write=True)(api_bj_stand))
    app.router.add_post("/api/earth/action", api(write=True)(api_earth_action))
    app.router.add_get("/api/admin/vaults", api(staff=True)(api_admin_vaults))
    app.router.add_post("/api/stocks/buy", api(write=True)(api_buy))
    app.router.add_post("/api/stocks/sell", api(write=True)(api_sell))
    app.router.add_post("/api/stocks/found", api(write=True)(api_found))
    app.router.add_post("/api/admin/stocks/price", api(write=True, staff=True)(api_admin_price))
    app.router.add_post("/api/admin/stocks/delist", api(write=True, staff=True)(api_admin_delist))
    return app


web_runner = None


async def start_web():
    global web_runner
    if not WEB_ENABLED:
        print("Website API is off (set DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET, WEB_BASE_URL and SESSION_SECRET to turn it on).")
        return
    try:
        web_runner = web.AppRunner(build_web_app())
        await web_runner.setup()
        await web.TCPSite(web_runner, WEB_HOST, WEB_PORT).start()
        print(f"Website API listening on {WEB_HOST}:{WEB_PORT}")
    except OSError as e:
        print("Website API failed to start:", e)


# ---------------------------------------------------------------------------
for group in (bank_group, mayor_group, elect_group, end_group, election_group, treasury_group, marketbank_group):
    bot.tree.add_command(group)


@bot.event
async def on_ready():
    print(f"Online as {bot.user}")


bot.run(TOKEN)
